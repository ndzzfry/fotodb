(function(){
    // ===== DOM REFERENCES =====
    const urlGroup = document.getElementById('urlGroup');
    const countBtns = document.querySelectorAll('.count-btn');
    const processBtn = document.getElementById('processBtn');
    const btnLabel = document.getElementById('btnLabel');
    const btnSpin = document.getElementById('btnSpin');
    const resultPanel = document.getElementById('resultPanel');
    const loadingOverlay = document.getElementById('loadingOverlay');
    const loadingSub = document.getElementById('loadingSub');
    const historyList = document.getElementById('historyList');
    const clearHistoryBtn = document.getElementById('clearHistory');

    let currentCount = 1;
    let urlInputs = [];
    let previewData = {};

    // ============================================================
    //  HISTORY FUNCTIONS
    // ============================================================
    function getHistory() {
        try {
            return JSON.parse(localStorage.getItem('tiktok_history') || '[]');
        } catch { return []; }
    }

    function saveHistory(history) {
        localStorage.setItem('tiktok_history', JSON.stringify(history));
    }

    function addToHistory(entry) {
        const history = getHistory();
        const filtered = history.filter(h => h.url !== entry.url);
        filtered.unshift({ ...entry, timestamp: Date.now() });
        if(filtered.length > 100) filtered.length = 100;
        saveHistory(filtered);
        renderHistory();
    }

    function deleteHistoryItem(url) {
        let history = getHistory();
        history = history.filter(h => h.url !== url);
        saveHistory(history);
        renderHistory();
    }

    function clearAllHistory() {
        saveHistory([]);
        renderHistory();
        showNotification('info', 'Riwayat dihapus', 'Semua riwayat download telah dibersihkan.', 2000);
    }

    function renderHistory() {
        const history = getHistory();
        if(history.length === 0) {
            historyList.innerHTML = `
                <div class="history-empty">
                    <i class="far fa-folder-open" style="display:block;font-size:1.6rem;margin-bottom:10px;color:#2a2a2a;"></i>
                    Belum ada riwayat download
                </div>
            `;
            return;
        }

        let html = '';
        history.forEach(item => {
            const time = new Date(item.timestamp);
            const timeStr = time.toLocaleDateString('id-ID', {day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'});
            
            let badges = '';
            if(item.hasVideo) badges += '<span>Video</span>';
            if(item.hasAudio) badges += '<span>Audio</span>';
            if(item.hasImages) badges += '<span>Foto</span>';
            if(!badges) badges = '<span>Kosong</span>';

            html += `
                <div class="history-item">
                    <span class="h-icon"><i class="fas fa-link"></i></span>
                    <span class="h-link" title="${item.url}">${item.url}</span>
                    <span class="h-badge">${badges}</span>
                    <span class="h-time">${timeStr}</span>
                    <span class="h-delete" data-url="${item.url}"><i class="fas fa-times"></i></span>
                </div>
            `;
        });

        historyList.innerHTML = html;
        historyList.querySelectorAll('.h-delete').forEach(el => {
            el.addEventListener('click', function(e) {
                e.stopPropagation();
                const url = this.dataset.url;
                deleteHistoryItem(url);
            });
        });
    }

    // ============================================================
    //  NOTIFICATION
    // ============================================================
    function showNotification(type, title, message, duration = 4000) {
        const old = document.querySelector('.notification');
        if(old) { old.classList.remove('show'); setTimeout(()=>old.remove(),400); }

        const icons = { success:'✔', error:'✕', warning:'⚠', info:'ℹ' };
        const notif = document.createElement('div');
        notif.className = 'notification';
        notif.innerHTML = `
            <div class="notification-icon ${type}">${icons[type]||'ℹ'}</div>
            <div class="notification-content">
                <div class="notification-title">${title}</div>
                <div class="notification-message">${message}</div>
            </div>
            <button class="notification-close" onclick="this.closest('.notification').classList.remove('show'); setTimeout(()=>this.closest('.notification').remove(),400);">✕</button>
        `;
        document.body.appendChild(notif);
        requestAnimationFrame(()=>notif.classList.add('show'));

        if(duration>0) {
            setTimeout(()=>{
                notif.classList.remove('show');
                setTimeout(()=>notif.remove(),400);
            }, duration);
        }
    }

    // ============================================================
    //  BUILD INPUTS
    // ============================================================
    function buildInputs(count) {
        urlGroup.innerHTML = '';
        urlInputs = [];
        previewData = {};

        for(let i=0; i<count; i++) {
            const div = document.createElement('div');
            div.className = 'url-item';
            div.innerHTML = `
                <span class="idx">${i+1}</span>
                <input type="text" placeholder="Tempel link TikTok ${i+1}" class="url-field" data-idx="${i}">
                <span class="status-icon" id="status_${i}"><i class="fas fa-circle" style="font-size:0.4rem;"></i></span>
                <span class="clear-btn"><i class="fas fa-times-circle"></i></span>
                <div class="preview-container" id="preview_${i}"></div>
            `;
            urlGroup.appendChild(div);

            const input = div.querySelector('input');
            const clear = div.querySelector('.clear-btn');
            const statusIcon = div.querySelector('.status-icon');
            const previewContainer = div.querySelector('.preview-container');
            
            urlInputs.push(input);
            
            clear.addEventListener('click', ()=>{
                input.value = '';
                previewContainer.classList.remove('show');
                previewContainer.innerHTML = '';
                statusIcon.innerHTML = '<i class="fas fa-circle" style="font-size:0.4rem;"></i>';
                statusIcon.className = 'status-icon';
                delete previewData[i];
                input.focus();
            });
            
            input.addEventListener('input', function() {
                const val = this.value.trim();
                if(val && val.includes('tiktok.com')) {
                    autoPreview(i, val);
                } else if(val && !val.includes('tiktok.com')) {
                    statusIcon.innerHTML = '<i class="fas fa-exclamation-triangle"></i>';
                    statusIcon.className = 'status-icon error';
                    previewContainer.classList.remove('show');
                    previewContainer.innerHTML = '';
                } else {
                    statusIcon.innerHTML = '<i class="fas fa-circle" style="font-size:0.4rem;"></i>';
                    statusIcon.className = 'status-icon';
                    previewContainer.classList.remove('show');
                    previewContainer.innerHTML = '';
                }
            });
            
            input.addEventListener('keydown', (e)=>{
                if(e.key === 'Enter') {
                    e.preventDefault();
                    processBtn.click();
                }
            });
        }

        if(urlInputs.length) setTimeout(()=>urlInputs[0].focus(), 150);
    }

    // ============================================================
    //  AUTO PREVIEW
    // ============================================================
    let previewTimers = {};

    async function autoPreview(idx, url) {
        const statusIcon = document.getElementById(`status_${idx}`);
        const previewContainer = document.getElementById(`preview_${idx}`);
        
        if(previewTimers[idx]) clearTimeout(previewTimers[idx]);
        
        statusIcon.innerHTML = '<i class="fas fa-spinner"></i>';
        statusIcon.className = 'status-icon loading';
        previewContainer.classList.remove('show');
        previewContainer.innerHTML = '';
        
        previewTimers[idx] = setTimeout(async () => {
            try {
                const apiUrl = `https://www.tikwm.com/api/?url=${encodeURIComponent(url)}`;
                const resp = await fetch(apiUrl);
                const json = await resp.json();
                
                if(json.code !== 0 || !json.data) {
                    statusIcon.innerHTML = '<i class="fas fa-times"></i>';
                    statusIcon.className = 'status-icon error';
                    previewContainer.innerHTML = `<div class="preview-error"><i class="fas fa-exclamation-circle"></i> ${json.msg || 'Data tidak ditemukan'}</div>`;
                    previewContainer.classList.add('show');
                    return;
                }
                
                const data = json.data;
                previewData[idx] = data;
                let html = '';
                let hasContent = false;
                
                // Video preview
                if(data.play) {
                    html += `<div class="preview-label"><i class="fas fa-film"></i> Video Preview</div>`;
                    html += `<video controls src="${data.play}" preload="metadata"></video>`;
                    html += `<button class="dl-preview-btn" data-url="${data.play}" data-name="video_${idx+1}.mp4"><i class="fas fa-download"></i> Download Video</button>`;
                    hasContent = true;
                }
                
                // Audio preview
                if(data.music) {
                    if(hasContent) html += '<div style="margin-top:8px;"></div>';
                    html += `<div class="preview-label"><i class="fas fa-headphones"></i> Audio Preview</div>`;
                    html += `<audio controls src="${data.music}" preload="metadata"></audio>`;
                    html += `<button class="dl-preview-btn" data-url="${data.music}" data-name="audio_${idx+1}.mp3"><i class="fas fa-download"></i> Download Audio</button>`;
                    hasContent = true;
                }
                
                // Images preview
                if(data.images && Array.isArray(data.images) && data.images.length > 0) {
                    if(hasContent) html += '<div style="margin-top:8px;"></div>';
                    html += `<div class="preview-label"><i class="fas fa-images"></i> Foto Preview (${data.images.length})</div>`;
                    html += `<div class="photo-grid">`;
                    data.images.forEach((img, i2) => {
                        html += `<img src="${img}" alt="Foto ${i2+1}" loading="lazy" data-url="${img}" data-name="img_${idx+1}_${i2+1}.jpg">`;
                    });
                    html += `</div>`;
                    hasContent = true;
                }
                
                if(!hasContent) {
                    statusIcon.innerHTML = '<i class="fas fa-times"></i>';
                    statusIcon.className = 'status-icon error';
                    previewContainer.innerHTML = `<div class="preview-error"><i class="fas fa-exclamation-circle"></i> Tidak ada konten yang bisa diunduh</div>`;
                    previewContainer.classList.add('show');
                    return;
                }
                
                statusIcon.innerHTML = '<i class="fas fa-check"></i>';
                statusIcon.className = 'status-icon success';
                previewContainer.innerHTML = html;
                previewContainer.classList.add('show');
                
                // Attach download events
                previewContainer.querySelectorAll('.dl-preview-btn').forEach(btn => {
                    btn.addEventListener('click', function(e) {
                        e.stopPropagation();
                        const url = this.dataset.url;
                        const name = this.dataset.name;
                        startDownload(url, name);
                    });
                });
                previewContainer.querySelectorAll('.photo-grid img').forEach(img => {
                    img.addEventListener('click', function() {
                        const url = this.dataset.url;
                        const name = this.dataset.name;
                        startDownload(url, name);
                    });
                });
                
            } catch(err) {
                statusIcon.innerHTML = '<i class="fas fa-times"></i>';
                statusIcon.className = 'status-icon error';
                previewContainer.innerHTML = `<div class="preview-error"><i class="fas fa-exclamation-circle"></i> Gagal mengambil preview</div>`;
                previewContainer.classList.add('show');
            }
        }, 600);
    }

    // ============================================================
    //  DOWNLOAD
    // ============================================================
    async function startDownload(fileUrl, fileName) {
        loadingOverlay.style.display = 'flex';
        loadingSub.textContent = `Mengunduh ${fileName}`;
        try {
            const resp = await fetch(fileUrl, { mode: 'cors', cache: 'no-store' });
            if(!resp.ok) throw new Error();
            const blob = await resp.blob();
            const blobUrl = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = blobUrl;
            a.download = fileName;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(blobUrl);
            showNotification('success', 'Berhasil', `File ${fileName} terunduh.`, 2500);
        } catch(err) {
            showNotification('error', 'Gagal', `File ${fileName} tidak bisa diunduh, buka di tab baru.`, 3500);
            window.open(fileUrl, '_blank');
        } finally {
            loadingOverlay.style.display = 'none';
        }
    }

    // ============================================================
    //  EXTRACT SINGLE
    // ============================================================
    async function extractSingle(url) {
        try {
            const apiUrl = `https://www.tikwm.com/api/?url=${encodeURIComponent(url)}`;
            const resp = await fetch(apiUrl);
            const json = await resp.json();
            if(json.code !== 0 || !json.data) {
                return { error: json.msg || 'Data tidak ditemukan' };
            }
            const data = json.data;
            return {
                video: data.play || null,
                music: data.music || null,
                images: (data.images && Array.isArray(data.images)) ? data.images : []
            };
        } catch(e) {
            return { error: 'Koneksi gagal' };
        }
    }

    // ============================================================
    //  PROCESS ALL
    // ============================================================
    async function processAll() {
        const links = urlInputs.map(inp => inp.value.trim()).filter(v => v !== '');
        if(links.length === 0) {
            showNotification('warning', 'Link kosong', 'Isi minimal satu link TikTok.', 3000);
            return;
        }
        for(let l of links) {
            if(!l.includes('tiktok.com')) {
                showNotification('error', 'Link tidak valid', `"${l.substring(0,30)}..." bukan link TikTok.`, 4000);
                return;
            }
        }

        btnLabel.style.opacity = '0';
        btnSpin.style.display = 'inline-block';
        resultPanel.style.display = 'none';
        resultPanel.innerHTML = '';
        showNotification('info', 'Memproses', `Mengambil data dari ${links.length} link...`, 2000);

        let allResults = [];
        let hasError = false;

        for(let i=0; i<links.length; i++) {
            loadingSub.textContent = `Memproses link ${i+1} dari ${links.length}`;
            const res = await extractSingle(links[i]);
            allResults.push({ idx: i, url: links[i], data: res });
            if(res.error) hasError = true;
        }

        let html = '';
        for(let i=0; i<allResults.length; i++) {
            const item = allResults[i];
            const d = item.data;
            if(d.error) {
                html += `<div class="result-item" style="border-color:rgba(255,77,77,0.2);">
                    <div class="meta"><span class="idx">Link ${i+1}</span><span style="color:#ff4d4d;">Gagal</span></div>
                    <div style="font-size:0.8rem;color:#7a7a7a;">${d.error}</div>
                </div>`;
                continue;
            }
            let rowHtml = '';
            const hasVideo = !!d.video;
            const hasAudio = !!d.music;
            const hasImages = d.images && d.images.length > 0;

            addToHistory({
                url: item.url,
                hasVideo: hasVideo,
                hasAudio: hasAudio,
                hasImages: hasImages
            });

            if(hasVideo) {
                rowHtml += `<div class="dl-row" data-video="${d.video}" data-name="video_${i+1}.mp4">
                    <div class="dl-left"><i class="fas fa-film"></i><span>Video No WM</span></div>
                    <i class="fas fa-arrow-down dl-arrow"></i>
                </div>`;
            }
            if(hasAudio) {
                rowHtml += `<div class="dl-row" data-music="${d.music}" data-name="audio_${i+1}.mp3">
                    <div class="dl-left"><i class="fas fa-headphones"></i><span>Audio</span></div>
                    <i class="fas fa-arrow-down dl-arrow"></i>
                </div>`;
            }
            if(hasImages) {
                let photoHtml = '<div class="photo-stack">';
                d.images.forEach((img, idx2) => {
                    photoHtml += `<div class="photo-item" data-img="${img}" data-name="img_${i+1}_${idx2+1}.jpg">
                        <i class="far fa-image"></i><span>Foto ${idx2+1}</span>
                        <i class="fas fa-download" style="margin-left:6px;font-size:0.7rem;"></i>
                    </div>`;
                });
                photoHtml += '</div>';
                rowHtml += photoHtml;
            }
            if(!rowHtml) {
                rowHtml = `<div style="font-size:0.8rem;color:#6a6a6a;padding:8px 0;">Tidak ada konten unduhan</div>`;
            }
            html += `<div class="result-item">
                <div class="meta"><span class="idx">Link ${i+1}</span><span style="color:#6a6a6a;font-size:0.75rem;">${hasVideo ? 'Video' : ''} ${hasAudio ? 'Audio' : ''} ${hasImages ? 'Foto' : ''}</span></div>
                ${rowHtml}
            </div>`;
        }

        resultPanel.innerHTML = html;
        resultPanel.style.display = 'block';

        document.querySelectorAll('.dl-row[data-video]').forEach(el => {
            const url = el.dataset.video;
            const name = el.dataset.name;
            el.addEventListener('click', (e) => {
                e.stopPropagation();
                startDownload(url, name);
            });
        });
        document.querySelectorAll('.dl-row[data-music]').forEach(el => {
            const url = el.dataset.music;
            const name = el.dataset.name;
            el.addEventListener('click', (e) => {
                e.stopPropagation();
                startDownload(url, name);
            });
        });
        document.querySelectorAll('.photo-item[data-img]').forEach(el => {
            const url = el.dataset.img;
            const name = el.dataset.name;
            el.addEventListener('click', (e) => {
                e.stopPropagation();
                startDownload(url, name);
            });
        });

        btnLabel.style.opacity = '1';
        btnSpin.style.display = 'none';
        loadingSub.textContent = 'Selesai';
        setTimeout(()=>{ loadingSub.textContent = 'Mohon tunggu'; }, 800);

        if(hasError) {
            showNotification('warning', 'Beberapa gagal', 'Cek link yang error dan coba lagi.', 4000);
        } else {
            showNotification('success', 'Selesai', 'Semua link siap diunduh.', 3000);
        }
    }

    // ============================================================
    //  EVENTS & INIT
    // ============================================================
    processBtn.addEventListener('click', processAll);
    clearHistoryBtn.addEventListener('click', clearAllHistory);

    countBtns.forEach(btn=>{
        btn.addEventListener('click', function(){
            countBtns.forEach(b=>b.classList.remove('active'));
            this.classList.add('active');
            currentCount = parseInt(this.dataset.count, 10);
            buildInputs(currentCount);
            resultPanel.style.display = 'none';
            resultPanel.innerHTML = '';
        });
    });

    // ===== INIT =====
    buildInputs(1);
    renderHistory();

    window.addEventListener('load', ()=>{
        loadingOverlay.style.display = 'none';
        setTimeout(()=>{
            showNotification('info', 'Zxx Downloader Ganda', 'Masukkan link TikTok, preview akan muncul otomatis.', 3500);
        }, 400);
    });

})();