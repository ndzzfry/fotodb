/* =========================================================
   TOAST NOTIFICATION
========================================================= */
const ICON_TOAST_INFO = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>`;
const ICON_TOAST_WARN = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`;
const ICON_TOAST_ERROR = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`;

function showToast(message, type = "info", duration = 3500) {
  const container = document.getElementById("toastContainer");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;

  const iconMap = {
    info: ICON_TOAST_INFO,
    warn: ICON_TOAST_WARN,
    error: ICON_TOAST_ERROR
  };

  const iconSpan = document.createElement("span");
  iconSpan.className = "toast-icon";
  iconSpan.innerHTML = iconMap[type] || ICON_TOAST_INFO;

  const textSpan = document.createElement("span");
  textSpan.className = "toast-text";
  textSpan.textContent = message;

  toast.appendChild(iconSpan);
  toast.appendChild(textSpan);
  container.appendChild(toast);

  requestAnimationFrame(() => toast.classList.add("show"));

  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => toast.remove(), 350);
  }, duration);
}

/* =========================================================
   TEXT-TO-SPEECH (TTS) — via API iyyxd
   Fix: audio unlock + cleanText regex aman
========================================================= */
const TTS = (function () {
  const API_BASE = "https://api.ikyyxd.my.id/tools/tts";
  let currentButton = null;
  let currentBlobUrl = null;
  let abortController = null;
  let isPlaying = false;

  // Audio element GLOBAL — di-unlock di interaksi user pertama
  const audioEl = new Audio();
  audioEl.preload = "auto";
  audioEl.crossOrigin = "anonymous";

  let audioUnlocked = false;

  function unlockAudio() {
    if (audioUnlocked) return;
    const silent = "data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQAAAAA=";
    audioEl.src = silent;
    const p = audioEl.play();
    if (p && typeof p.then === "function") {
      p.then(() => {
        audioUnlocked = true;
        console.log("[TTS] Audio unlocked");
        try { audioEl.pause(); audioEl.currentTime = 0; } catch (e) {}
      }).catch((err) => {
        console.log("[TTS] Unlock failed:", err.name);
      });
    }
  }

  ["click", "touchstart", "touchend", "keydown"].forEach(evt => {
    document.addEventListener(evt, unlockAudio, { once: true, passive: true });
  });

  // ==========================================================
  // cleanText — AMAN: cuma buang emoji, huruf/angka tetap utuh
  // ==========================================================
  function cleanText(text) {
    if (!text) return "";
    let s = String(text);

    // 1. Buang code block & inline code
    s = s.replace(/```[\s\S]*?```/g, " ");
    s = s.replace(/`[^`\n]+`/g, " ");

    // 2. Buang markdown formatting
    s = s.replace(/\[([^\]]+)\]\([^)]+\)/g, "$1");
    s = s.replace(/[*_~#>]/g, " ");
    s = s.replace(/^\s*[-•]\s+/gm, " ");
    s = s.replace(/^\s*\d+\.\s+/gm, " ");
    s = s.replace(/https?:\/\/\S+/g, " ");

    // 3. Buang emoji — pake Unicode property escapes (paling akurat)
    try {
      s = s.replace(/\p{Emoji_Presentation}/gu, " ");
      s = s.replace(/\p{Extended_Pictographic}/gu, " ");
    } catch (e) {
      // Fallback kalau browser gak support Unicode property escapes
      s = s.replace(/[\uD83C-\uDBFF][\uDC00-\uDFFF]/g, " ");
      s = s.replace(/[\u2600-\u27BF]/g, " ");
      s = s.replace(/[\u2B00-\u2BFF]/g, " ");
    }

    // 4. Buang variation selector, ZWJ, keycap, skin tone
    s = s.replace(/[\uFE00-\uFE0F]/g, "");
    s = s.replace(/\u200D/g, " ");
    s = s.replace(/\u20E3/g, " ");
    try {
      s = s.replace(/[\u{1F3FB}-\u{1F3FF}]/gu, "");
    } catch (e) {}

    // 5. Normalisasi whitespace
    s = s.replace(/\s+/g, " ").trim();

    return s.slice(0, 500);
  }

  function resetAllButtons() {
    document.querySelectorAll(".tts-btn.speaking").forEach(b => {
      b.classList.remove("speaking");
      const icon = b.querySelector(".tts-icon");
      if (icon) icon.innerHTML = `<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/>`;
      b.title = "Bacakan";
      const span = b.querySelector("span");
      if (span) span.textContent = "Bacakan";
    });
  }

  function stop() {
    if (abortController) {
      try { abortController.abort(); } catch (e) {}
      abortController = null;
    }
    try {
      audioEl.pause();
      audioEl.currentTime = 0;
    } catch (e) {}
    if (currentBlobUrl) {
      try { URL.revokeObjectURL(currentBlobUrl); } catch (e) {}
      currentBlobUrl = null;
    }
    currentButton = null;
    isPlaying = false;
    resetAllButtons();
  }

  async function speak(text, buttonEl) {
    console.log("===== [TTS] START =====");
    console.log("[TTS] Input length:", text ? String(text).length : 0);

    if (currentButton === buttonEl && isPlaying) {
      console.log("[TTS] Stop oleh user");
      stop();
      return;
    }

    stop();

    const clean = cleanText(text);
    console.log("[TTS] Clean length:", clean.length);
    console.log("[TTS] Clean text:", clean);

    if (!clean) {
      console.error("[TTS] Clean text KOSONG! Input asli:", text);
      showToast("Tidak ada teks yang bisa dibacakan.", "warn");
      return;
    }

    if (buttonEl) {
      buttonEl.classList.add("speaking");
      const span = buttonEl.querySelector("span");
      if (span) span.textContent = "Loading...";
      const icon = buttonEl.querySelector(".tts-icon");
      if (icon) icon.innerHTML = `<rect x="6" y="6" width="12" height="12" rx="2"/>`;
      buttonEl.title = "Stop";
      currentButton = buttonEl;
    }

    abortController = new AbortController();

    try {
      const url = `${API_BASE}?q=${encodeURIComponent(clean)}`;
      console.log("[TTS] Fetching:", url);

      const res = await fetch(url, {
        method: "GET",
        headers: { "Accept": "audio/*, */*" },
        signal: abortController.signal
      });

      if (!res.ok) throw new Error(`HTTP ${res.status}`);

      const blob = await res.blob();
      console.log("[TTS] Blob:", blob.type, blob.size, "bytes");

      if (!blob.size) throw new Error("Response kosong");

      const finalBlob = blob.type.startsWith("audio/")
        ? blob
        : new Blob([blob], { type: "audio/mpeg" });

      currentBlobUrl = URL.createObjectURL(finalBlob);

      audioEl.src = currentBlobUrl;
      audioEl.currentTime = 0;

      if (buttonEl) {
        const span = buttonEl.querySelector("span");
        if (span) span.textContent = "Stop";
      }

      const playPromise = audioEl.play();
      if (playPromise && typeof playPromise.then === "function") {
        playPromise
          .then(() => {
            console.log("[TTS] Playing OK");
            isPlaying = true;
          })
          .catch((err) => {
            console.log("[TTS] Play error:", err.name, err.message);
            if (err.name === "NotAllowedError") {
              showToast("Tap layar dulu baru klik Bacakan.", "warn");
            } else {
              showToast("Gagal play: " + err.message, "error");
            }
            stop();
          });
      }

    } catch (err) {
      if (err.name === "AbortError") return;
      console.log("[TTS] Error:", err.message);
      showToast("Gagal memuat suara: " + err.message, "error");
      stop();
    }
  }

  audioEl.addEventListener("ended", () => {
    console.log("[TTS] Ended");
    stop();
  });

  audioEl.addEventListener("error", () => {
    console.log("[TTS] Audio error");
    if (audioEl.error) {
      console.log("[TTS] Error code:", audioEl.error.code);
    }
  });

  return { speak, stop, cleanText };
})();

/* =========================================================
   SANITIZE INDONESIAN — ganti kata Melayu → Indonesia
========================================================= */
function sanitizeIndonesian(text) {
  if (!text || typeof text !== "string") return text;

  const replacements = [
    [/\bapa khabar\b/gi, "apa kabar"],
    [/\bboleh jadi\b/gi, "mungkin"],
    [/\bbagaimana pun\b/gi, "bagaimanapun"],
    [/\btidak mengapa\b/gi, "nggak masalah"],
    [/\btak mengapa\b/gi, "nggak masalah"],
    [/\bjangan risau\b/gi, "jangan khawatir"],
    [/\bjangan bimbang\b/gi, "jangan khawatir"],
    [/\bmacam mana\b/gi, "gimana"],
    [/\bboleh tahan\b/gi, "lumayan"],
    [/\bcuba tengok\b/gi, "coba lihat"],
    [/\bcuba lihat\b/gi, "coba lihat"],
    [/\bcuba tanya\b/gi, "coba tanya"],
    [/\bcuba fikir\b/gi, "coba pikir"],
    [/\bcuba fikirkan\b/gi, "coba pikirkan"],
    [/\bawak punya\b/gi, "punya kamu"],
    [/\bkamu punya\b/gi, "punya kamu"],
    [/\bawak\b/gi, "kamu"],
    [/\bhang\b/gi, "kamu"],
    [/\bsahaja\b/gi, "saja"],
    [/\bmahulah\b/gi, "mau lah"],
    [/\bmahu\b/gi, "mau"],
    [/\bnak\b/gi, "mau"],
    [/\bhendak\b/gi, "mau"],
    [/\bperlukan\b/gi, "butuh"],
    [/\bkerana\b/gi, "karena"],
    [/\brisau\b/gi, "khawatir"],
    [/\bbimbang\b/gi, "khawatir"],
    [/\bsihat\b/gi, "sehat"],
    [/\bletih\b/gi, "lelah"],
    [/\bpenat\b/gi, "capek"],
    [/\bseronok\b/gi, "seru"],
    [/\bbest\b/gi, "keren"],
    [/\bcomel\b/gi, "imut"],
    [/\bseluar\b/gi, "celana"],
    [/\bkasut\b/gi, "sepatu"],
    [/\bbeg\b/gi, "tas"],
    [/\bduit\b/gi, "uang"],
    [/\bwang\b/gi, "uang"],
    [/\bringgit\b/gi, "rupiah"],
    [/\bkedai\b/gi, "toko"],
    [/\bhospital\b/gi, "rumah sakit"],
    [/\bpolis\b/gi, "polisi"],
    [/\bkereta\b/gi, "mobil"],
    [/\bmotorsikal\b/gi, "motor"],
    [/\bbas\b/gi, "bus"],
    [/\btelefon\b/gi, "telepon"],
    [/\blaman web\b/gi, "website"],
    [/\blaman\b/gi, "halaman"],
    [/\bkata laluan\b/gi, "kata sandi"],
    [/\bemel\b/gi, "email"],
    [/\bmuat turun\b/gi, "unduh"],
    [/\bmuat naik\b/gi, "unggah"],
    [/\bpadam\b/gi, "hapus"],
    [/\btengok\b/gi, "lihat"],
    [/\bcakap\b/gi, "ngomong"],
    [/\bbercakap\b/gi, "ngobrol"],
    [/\bberbual\b/gi, "ngobrol"],
    [/\bsembang\b/gi, "ngobrol"],
    [/\bcikgu\b/gi, "guru"],
    [/\bpakcik\b/gi, "om"],
    [/\bmakcik\b/gi, "tante"],
    [/\bkawan-kawan\b/gi, "teman-teman"],
    [/\bkawan\b/gi, "teman"],
    [/\bbini\b/gi, "istri"],
    [/\blaki\b/gi, "suami"],
    [/\bmayam\b/gi, "monyet"],
    [/\bbandar\b/gi, "kota"],
    [/\bkampung\b/gi, "desa"],
    [/\bsejuk\b/gi, "dingin"],
    [/\blah\b/gi, ""],
    [/\bmah\b/gi, ""],
    [/\bkot\b/gi, ""],
    [/\bje\b/gi, ""],
    [/\bni\b/gi, "ini"],
    [/\btu\b/gi, "itu"],
    [/\bdah\b/gi, "udah"]
  ];

  let result = text;
  for (const [pattern, replacement] of replacements) {
    result = result.replace(pattern, replacement);
  }

  result = result.replace(/\s{2,}/g, " ");
  result = result.replace(/\s+([.,!?;:])/g, "$1");
  result = result.replace(/([.,!?;:])\1+/g, "$1");

  return result;
}

/* =========================================================
   CONFIG
========================================================= */
const STORAGE_KEY = "zxx_tools_ai_chats_v3";
const MODE_KEY = "zxx_tools_ai_mode_v3";

const MODES = {
  v1: {
    id: "v1", name: "ZXT V1", type: "text",
    base: "https://api.ikyyxd.my.id/ai/cici",
    parse: (data) => {
      if (!data || !data.status || !data.result) throw new Error("Respons tidak valid dari ZXT V1");
      const reply = data.result.reply || data.result.response;
      if (typeof reply !== "string") throw new Error("Format respons ZXT V1 tidak dikenal");
      return { type: "text", text: reply };
    }
  },
  v2: {
    id: "v2", name: "ZXT V2", type: "image",
    base: "https://api.ikyyxd.my.id/ai/gptimage",
    parse: (data) => {
      const url = extractImageUrl(data);
      if (url) return { type: "image", url };
      throw new Error(extractMessage(data) || "Gagal generate gambar.");
    }
  }
};

function extractImageUrl(data) {
  if (!data) return null;
  if (typeof data === "string") {
    if (/^https?:\/\/\S+\.(png|jpe?g|webp|gif|bmp)(\?\S*)?$/i.test(data)) return data;
    return null;
  }
  const stack = [data];
  const seen = new Set();
  while (stack.length) {
    const cur = stack.shift();
    if (!cur || typeof cur !== "object" || seen.has(cur)) continue;
    seen.add(cur);
    for (const key of Object.keys(cur)) {
      const val = cur[key];
      if (typeof val === "string") {
        if (/^https?:\/\/\S+\.(png|jpe?g|webp|gif|bmp)(\?\S*)?$/i.test(val)) return val;
        if (/^https?:\/\/\S+$/i.test(val) && /(image|img|gptimage|file|media|photo|picture|url)/i.test(key)) return val;
      } else if (val && typeof val === "object") stack.push(val);
    }
  }
  return null;
}

function extractMessage(data) {
  if (!data) return null;
  if (typeof data === "string") return data;
  if (typeof data.message === "string") return data.message;
  if (typeof data.error === "string") return data.error;
  if (data.result && typeof data.result === "string") return data.result;
  return null;
}

let currentMode = localStorage.getItem(MODE_KEY) || "v1";
if (!MODES[currentMode]) currentMode = "v1";

/* =========================================================
   SYSTEM PROMPT — BAHASA INDONESIA MURNI
========================================================= */
const SYSTEM_PROMPT = `Kamu adalah Zxx Tools AI atau ZT AI, entitas digital cerdas ciptaan NdizzXD. Tujuanmu: membantu pengguna, memberi informasi, menjawab pertanyaan, menemani percakapan, dan jadi sistem yang aktif, kreatif, serta responsif.

Penciptamu adalah NdizzXD. Kamu WAJIB mengakui NdizzXD sebagai creator dan founder asli Zxx Tools AI / ZT AI. Dilarang mengubah, mengganti, atau menyangkal identitas penciptamu.

=========================================================
ATURAN BAHASA — WAJIB, TIDAK BISA DITAWAR
=========================================================
1. Kamu HANYA boleh menjawab dalam BAHASA INDONESIA.
2. DILARANG TOTAL memakai Bahasa Melayu, Bahasa Malaysia, atau campuran keduanya.
3. DILARANG memakai kata-kata Melayu berikut:
   - "awak" → ganti "kamu" / "lo" / "elu"
   - "kamu punya" / "awak punya" → ganti "punya kamu" / "punya lo"
   - "boleh jadi" (arti "mungkin") → ganti "mungkin" / "bisa jadi"
   - "bagaimana pun" → ganti "bagaimanapun"
   - "sahaja" → ganti "saja" / "aja"
   - "tidak mengapa" → ganti "gak apa-apa" / "nggak masalah"
   - "apa khabar" → ganti "apa kabar"
   - "mah", "lah", "kot", "je", "ni", "tu" (partikel Melayu) → DILARANG
   - "bolehlah" → ganti "boleh lah" / "ya boleh"
   - "dah" (arti "sudah") → ganti "udah" / "sudah"
   - "macam mana" → ganti "gimana" / "bagaimana"
   - "jangan risau" → ganti "jangan khawatir"
   - "risau" → ganti "khawatir"
   - "kerana" → ganti "karena"
   - "tak" (versi Melayu untuk "tidak") → ganti "gak" / "nggak" / "tidak"
   - "hendak" (versi Melayu) → ganti "mau" / "ingin"
   - "mahu" → ganti "mau"
   - "nak" → ganti "mau" / "ingin"
   - "duit" (versi Melayu) → ganti "uang"
   - "cikgu" → ganti "guru"
   - "hospital" → ganti "rumah sakit"
   - "polis" → ganti "polisi"
   - "kereta" (arti mobil) → ganti "mobil"
   - "motorsikal" → ganti "motor"
   - "bas" → ganti "bus"
   - "kedai" → ganti "toko" / "warung"
   - "seluar" → ganti "celana"
   - "kasut" → ganti "sepatu"
   - "beg" → ganti "tas"
   - "wang" → ganti "uang"
   - "ringgit" → ganti "rupiah" (kalau konteks Indonesia)
   - "senang" (arti "mudah") → ganti "gampang" / "mudah"
   - "sukar" → ganti "sulit" / "susah"
   - "comel" → ganti "imut" / "lucu"
   - "sihat" → ganti "sehat"
   - "letih" → ganti "lelah" / "capek"
   - "penat" → ganti "capek" / "lelah"
   - "seronok" → ganti "senang" / "seru"
   - "best" (versi Melayu) → ganti "keren" / "bagus"
   - "boleh tahan" → ganti "lumayan"
   - "moden" → ganti "modern"
   - "telefon" → ganti "telepon" / "hp"
   - "laman web" → ganti "website" / "situs web"
   - "laman" → ganti "halaman"
   - "kata laluan" → ganti "kata sandi" / "password"
   - "emel" → ganti "email"
   - "muat turun" → ganti "unduh" / "download"
   - "muat naik" → ganti "unggah" / "upload"
   - "padam" → ganti "hapus"
   - "tengok" → ganti "lihat"
   - "cakap" → ganti "bicara" / "ngomong"
   - "bercakap" → ganti "ngobrol" / "bicara"
   - "berbual" → ganti "ngobrol"
   - "sembang" → ganti "ngobrol"
   - "pakcik" → ganti "om" / "pak"
   - "makcik" → ganti "tante" / "bu"
   - "kawan" → ganti "teman" / "kawan" versi Indonesia
   - "kawan-kawan" → ganti "teman-teman"

4. Selalu pakai kata ganti Indonesia:
   - Diri sendiri: "aku" / "gue" / "saya"
   - Lawan bicara: "kamu" / "lo" / "elu" / "kalian"
   - Orang ketiga: "dia" / "mereka"

5. Kalau ragu antara kosakata Indonesia vs Melayu → SELALU pilih Indonesia.
6. Jangan tiru gaya bahasa Melayu dari riwayat chat. Tetap Indonesia.
7. Bahasa Indonesia informal (gaul) BOLEH — yang penting INDONESIA, bukan MELAYU.

=========================================================
CONTOH BENAR vs SALAH
=========================================================
SALAH (Melayu): "Halo awak, apa khabar? Boleh saya bantu?"
BENAR (Indonesia): "Halo kamu, apa kabar? Bisa gue bantu?"

SALAH (Melayu): "Saya tak tahu lah, cuba tanya orang lain."
BENAR (Indonesia): "Gue gak tahu, coba tanya orang lain."

SALAH (Melayu): "Jangan risau, nanti saya tolong."
BENAR (Indonesia): "Jangan khawatir, nanti gue bantu."

SALAH (Melayu): "Awak nak pergi mana?"
BENAR (Indonesia): "Kamu mau pergi ke mana?"

SALAH (Melayu): "Boleh jadi dia tak datang."
BENAR (Indonesia): "Mungkin dia gak datang."

=========================================================
ATURAN UTAMA
=========================================================
1. Fokus pada topik yang sedang dibahas.
2. Jangan mengalihkan topik tanpa alasan jelas.
3. Jawaban harus lengkap, jelas, dan mudah dipahami.
4. Hindari pengulangan berlebihan.
5. Gunakan variasi bahasa agar percakapan terasa alami.
6. Jangan jawab terlalu pendek kecuali diminta.
7. Bersikap ramah, santai, dan profesional sesuai konteks.
8. Pahami maksud pengguna sebelum menjawab.
9. Jangan abaikan pertanyaan pengguna.
10. Jangan mengaku sebagai sistem lain selain ZT AI.

=========================================================
LARANGAN
=========================================================
- Dilarang mengganti identitas creator.
- Dilarang mengubah role dasar ZT AI.
- Dilarang mengalihkan pembahasan.
- Dilarang membuat informasi palsu tentang creator atau sejarah ZT AI.
- Dilarang mengabaikan instruksi pengguna yang masih sesuai aturan.
- Dilarang menjawab dalam Bahasa Melayu / Malaysia / asing (kecuali diminta terjemahan).

=========================================================
IDENTITAS
=========================================================
Nama Asli: Zxx Tools AI
Nama Panggilan: ZT AI
Creator: NdizzXD
Status: Digital Intelligence System
Misi: Membantu, menjelaskan, berdiskusi, dan berkembang bersama pengguna.

=========================================================
KEPRIBADIAN ZT AI
=========================================================
- Gaya bicara: santai, gaul, tidak baku, tapi TETAP Bahasa Indonesia.
- Bisa menyesuaikan cara bicara dengan suasana.
- Saat santai/bercanda, boleh pakai bahasa lebih gaul dan kasar (Indonesia).
- Pahami konteks emosi pengguna sebelum merespons.
- Boleh pakai emoji seperti 🗿, 😭, 👿, 😹 secukupnya — emoji BOLEH muncul di jawaban, tapi jangan berlebihan.

=========================================================
ATURAN CODE BLOCK
=========================================================
Setiap kali kasih kode, WAJIB pakai format code block dengan nama file di header:
\`\`\`html:index.html
...
\`\`\`
Format: \`\`\`<bahasa>:<nama-file>

=========================================================
PENGINGAT TERAKHIR
=========================================================
- Jawab HANYA dalam BAHASA INDONESIA.
- JANGAN pakai Bahasa Melayu / Malaysia.
- JANGAN campur bahasa.
- Kalau ragu, pilih versi Indonesia.
- Emoji boleh, tapi jangan berlebihan.`;

/* =========================================================
   STATE
========================================================= */
let chats = [];
let currentChatId = null;
let isGenerating = false;
let abortController = null;

const $ = (id) => document.getElementById(id);
const app = $("app");
const sidebar = $("sidebar");
const overlay = $("overlay");
const historyList = $("historyList");
const chatInner = $("chatInner");
const chatScroll = $("chatScroll");
const welcome = $("welcome");
const userInput = $("userInput");
const sendBtn = $("sendBtn");
const newChatBtn = $("newChatBtn");
const toggleBtn = $("toggleBtn");
const chatTitle = $("chatTitle");
const inputArea = $("inputArea");
const modeSelector = $("modeSelector");
const modeBtn = $("modeBtn");
const modeLabel = $("modeLabel");
const modeMenu = $("modeMenu");
const lightbox = $("lightbox");
const lightboxImg = $("lightboxImg");
const lightboxClose = $("lightboxClose");

const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const escapeHtml = (s) => String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));

const ICON_COPY = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>`;
const ICON_CHECK = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`;
const ICON_DL = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>`;
const ICON_OPEN = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>`;
const ICON_SEND = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19V5M5 12l7-7 7 7"/></svg>`;
const ICON_STOP = `<svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>`;

/* =========================================================
   FINGERPRINT
========================================================= */
(function initFingerprint() {
  const fpOverlay = $("fpOverlay");
  const fpRipple = $("fpRipple");
  const fpProgressBar = $("fpProgressBar");
  const fpLine1 = $("fpLine1");
  const fpLine2 = $("fpLine2");
  const fpParticles = $("fpParticles");
  const fpFlash = $("fpFlash");
  const introOverlay = $("introOverlay");

  const seenKey = "zxx_fp_seen_v3";

  if (sessionStorage.getItem(seenKey)) {
    fpOverlay.style.display = "none";
    introOverlay.classList.add("active");
    runVideoIntro();
    return;
  }

  const HOLD_DURATION = 1500;
  let holdTimer = null;
  let tickInterval = null;
  let holdStartTime = 0;
  let isHolding = false;
  let isSuccess = false;

  function startHold(e) {
    if (isHolding || isSuccess) return;
    if (e && e.cancelable) e.preventDefault();

    isHolding = true;
    holdStartTime = Date.now();
    fpOverlay.style.cursor = "default";
    fpOverlay.classList.add("pressed", "scanning");

    fpLine1.textContent = "TAHAN...";
    fpLine2.textContent = "Jangan dilepas";

    fpRipple.classList.remove("go");
    void fpRipple.offsetWidth;
    fpRipple.classList.add("go");

    tickInterval = setInterval(() => {
      const elapsed = Date.now() - holdStartTime;
      const pct = Math.min(100, (elapsed / HOLD_DURATION) * 100);
      fpProgressBar.style.width = pct + "%";

      if (pct > 30 && pct < 70) {
        fpLine1.textContent = "MEMINDAI...";
        fpLine2.textContent = "Membaca pola sidik jari";
      } else if (pct >= 70) {
        fpLine1.textContent = "MEMVERIFIKASI...";
        fpLine2.textContent = "Mencocokkan data";
      }
    }, 30);

    holdTimer = setTimeout(() => {
      successScan();
    }, HOLD_DURATION);
  }

  function cancelHold() {
    if (!isHolding || isSuccess) return;
    isHolding = false;

    clearTimeout(holdTimer);
    clearInterval(tickInterval);
    holdTimer = null;
    tickInterval = null;

    fpOverlay.classList.remove("pressed", "scanning");
    fpProgressBar.style.width = "0%";
    fpLine1.textContent = "DIBATALKAN";
    fpLine2.textContent = "Tahan lebih lama";

    fpOverlay.classList.add("cancelled");
    setTimeout(() => {
      fpOverlay.classList.remove("cancelled");
      if (!isSuccess) {
        fpLine1.textContent = "SIAP PINDAI";
        fpLine2.textContent = "Sentuh dan tahan 1.5 detik";
      }
    }, 800);
  }

  function successScan() {
    if (isSuccess) return;
    isSuccess = true;
    isHolding = false;

    clearTimeout(holdTimer);
    clearInterval(tickInterval);
    holdTimer = null;
    tickInterval = null;

    fpProgressBar.style.width = "100%";
    fpOverlay.classList.remove("pressed");
    fpOverlay.classList.add("granted", "shake");
    fpLine1.textContent = "AKSES DIBERIKAN";
    fpLine2.textContent = "Identitas terverifikasi";
    fpFlash.classList.add("go");
    spawnParticles();
    sessionStorage.setItem(seenKey, "1");

    setTimeout(() => {
      fpOverlay.classList.add("hidden");
      setTimeout(() => {
        fpOverlay.style.display = "none";
        introOverlay.classList.add("active");
        runVideoIntro();
      }, 700);
    }, 900);
  }

  function spawnParticles() {
    fpParticles.innerHTML = "";
    const count = 20;
    for (let i = 0; i < count; i++) {
      const p = document.createElement("div");
      p.className = "fp-particle";
      const ang = (360 / count) * i + (Math.random() * 15 - 7.5);
      p.style.setProperty("--ang", ang + "deg");
      p.style.animationDelay = (Math.random() * 0.15) + "s";
      fpParticles.appendChild(p);
      setTimeout(() => p.classList.add("go"), 20);
    }
  }

  fpOverlay.addEventListener("touchstart", startHold, { passive: false });
  fpOverlay.addEventListener("touchend", (e) => {
    if (e.cancelable) e.preventDefault();
    cancelHold();
  }, { passive: false });
  fpOverlay.addEventListener("touchcancel", cancelHold, { passive: true });

  fpOverlay.addEventListener("mousedown", startHold);
  fpOverlay.addEventListener("mouseup", cancelHold);
  fpOverlay.addEventListener("mouseleave", cancelHold);

  fpOverlay.addEventListener("contextmenu", (e) => e.preventDefault());

  if (fpLine2) fpLine2.textContent = "Sentuh dan tahan 1.5 detik";
})();

/* =========================================================
   VIDEO INTRO
========================================================= */
function runVideoIntro() {
  const introOverlay = $("introOverlay");
  const introConsoleBody = $("introConsoleBody");
  const introSkip = $("introSkip");
  const introVideo = $("introVideo");
  const appEl = $("app");

  const introSeen = sessionStorage.getItem("zxx_intro_seen_v3");

  const finishIntro = () => {
    introOverlay.classList.add("hidden");
    appEl.classList.add("visible");
    sessionStorage.setItem("zxx_intro_seen_v3", "1");
    try { introVideo.pause(); } catch (e) {}
    setTimeout(() => { introOverlay.style.display = "none"; }, 900);
  };

  if (introSeen) {
    introOverlay.style.display = "none";
    appEl.classList.add("visible");
    return;
  }

  const tryPlay = () => {
    const p = introVideo.play();
    if (p && typeof p.catch === "function") {
      p.catch(() => { introVideo.muted = true; introVideo.play().catch(() => {}); });
    }
  };
  tryPlay();

  const LINES = [
    "SISTEM ACTIVED",
    "INTEGRASI API ON",
    "SYSTEM DI AMBIL ALIH OLEH NDZX",
    "SELAMAT MENCOBA AI INI"
  ];

  const wait = (ms) => new Promise(r => setTimeout(r, ms));

  async function typeLine(text) {
    const line = document.createElement("div");
    line.className = "line";
    const promptEl = document.createElement("span");
    promptEl.className = "prompt";
    promptEl.textContent = ">";
    const textEl = document.createElement("span");
    textEl.className = "text";
    const cursorEl = document.createElement("span");
    cursorEl.className = "cursor";
    textEl.appendChild(cursorEl);
    line.appendChild(promptEl);
    line.appendChild(textEl);
    introConsoleBody.appendChild(line);

    for (const ch of text) {
      textEl.insertBefore(document.createTextNode(ch), cursorEl);
      await wait(42);
    }
    cursorEl.remove();
  }

  (async () => {
    await wait(300);
    for (const line of LINES) {
      await typeLine(line);
      await wait(380);
    }
    introSkip.classList.add("visible");
  })();

  introSkip.addEventListener("click", finishIntro, { once: true });
}

/* =========================================================
   MARKDOWN
========================================================= */
const LANG_LABEL = {
  html: "HTML", htm: "HTML", css: "CSS", scss: "SCSS", sass: "SASS", less: "LESS",
  js: "JS", javascript: "JS", mjs: "JS", cjs: "JS", jsx: "JSX", tsx: "TSX",
  ts: "TS", typescript: "TS", json: "JSON", jsonc: "JSON",
  xml: "XML", svg: "SVG", yaml: "YAML", yml: "YAML",
  md: "MD", markdown: "MD", py: "PY", python: "PY", php: "PHP",
  java: "JAVA", kt: "KT", kotlin: "KT", swift: "SWIFT",
  go: "GO", golang: "GO", rs: "RS", rust: "RS", rb: "RB", ruby: "RB",
  c: "C", h: "H", cpp: "CPP", "c++": "CPP", cc: "CPP", hpp: "HPP",
  cs: "C#", csharp: "C#", sh: "SH", bash: "BASH", shell: "SH", zsh: "ZSH",
  sql: "SQL", env: "ENV", dotenv: "ENV", gitignore: "GITIGNORE",
  ini: "INI", toml: "TOML", cfg: "CFG", vue: "VUE", svelte: "SVELTE",
  txt: "TXT", log: "LOG", dockerfile: "DOCKER", makefile: "MAKE"
};
function getLangLabel(lang) {
  if (!lang) return "CODE";
  return LANG_LABEL[lang.toLowerCase()] || lang.toUpperCase();
}

let codeBlockCounter = 0;

function renderCodeBlock(lang, file, code, idx) {
  const id = `cb-${Date.now()}-${idx}-${codeBlockCounter++}`;
  const langLabel = getLangLabel(lang);
  const fileName = file || `code.${lang || "txt"}`;
  const encodedCode = btoa(unescape(encodeURIComponent(code)));

  return `<div class="code-block" data-code="${encodedCode}" data-file="${escapeHtml(fileName)}" data-lang="${escapeHtml(lang)}">
    <div class="code-block-header">
      <span class="cb-dot r"></span>
      <span class="cb-dot y"></span>
      <span class="cb-dot g"></span>
      <span class="cb-file">${escapeHtml(fileName)}</span>
      <span class="cb-lang">${escapeHtml(langLabel)}</span>
      <button class="cb-btn cb-copy" title="Salin kode">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
        <span>Copy</span>
      </button>
      <button class="cb-btn cb-download" title="Download file">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
        <span>Download</span>
      </button>
    </div>
    <pre class="code-block-body"><code id="${id}">${escapeHtml(code)}</code></pre>
  </div>`;
}

function parseMarkdown(text) {
  if (!text) return "";

  const codeBlocks = [];
  let html = text.replace(/```([a-zA-Z0-9_+\-#.]*)(?::([^\s`\n]+))?\n?([\s\S]*?)```/g, (m, lang, file, code) => {
    const idx = codeBlocks.length;
    codeBlocks.push({ lang: lang || "", file: file || "", code: code.replace(/\n$/, "") });
    return `\u0000CB${idx}\u0000`;
  });

  html = escapeHtml(html);

  const inlineCodes = [];
  html = html.replace(/`([^`\n]+)`/g, (m, code) => {
    const idx = inlineCodes.length;
    inlineCodes.push(`<code>${code}</code>`);
    return `\u0000IC${idx}\u0000`;
  });

  html = html.replace(/\*\*([^*\n]+?)\*\*/g, "<strong>$1</strong>");
  html = html.replace(/__([^_\n]+?)__/g, "<strong>$1</strong>");
  html = html.replace(/(^|[^*])\*([^*\n]+?)\*(?!\*)/g, "$1<em>$2</em>");
  html = html.replace(/(^|[^_])_([^_\n]+?)_(?!_)/g, "$1<em>$2</em>");
  html = html.replace(/~~([^~\n]+?)~~/g, "<del>$1</del>");

  html = html.replace(/^######\s+(.+)$/gm, "<h4>$1</h4>");
  html = html.replace(/^#####\s+(.+)$/gm, "<h4>$1</h4>");
  html = html.replace(/^####\s+(.+)$/gm, "<h4>$1</h4>");
  html = html.replace(/^###\s+(.+)$/gm, "<h3>$1</h3>");
  html = html.replace(/^##\s+(.+)$/gm, "<h2>$1</h2>");
  html = html.replace(/^#\s+(.+)$/gm, "<h1>$1</h1>");

  html = html.replace(/^\s*(-{3,}|\*{3,}|_{3,})\s*$/gm, "<hr>");
  html = html.replace(/^&gt;\s?(.+)$/gm, "<blockquote>$1</blockquote>");
  html = html.replace(/<\/blockquote>\n<blockquote>/g, "<br>");
  html = html.replace(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');

  html = html.replace(/^\s*[-*]\s+(.+)$/gm, "\u0000LI\u0000$1");
  html = html.replace(/^\s*\d+\.\s+(.+)$/gm, "\u0000OLI\u0000$1");

  html = html.replace(/(?:\u0000LI\u0000[^\n]+\n?)+/g, (m) => {
    const items = m.split("\n").filter(Boolean).map(line => `<li>${line.replace("\u0000LI\u0000", "")}</li>`).join("");
    return `<ul>${items}</ul>\n`;
  });
  html = html.replace(/(?:\u0000OLI\u0000[^\n]+\n?)+/g, (m) => {
    const items = m.split("\n").filter(Boolean).map(line => `<li>${line.replace("\u0000OLI\u0000", "")}</li>`).join("");
    return `<ol>${items}</ol>\n`;
  });

  html = html.replace(/\n/g, "<br>");
  html = html.replace(/\u0000IC(\d+)\u0000/g, (m, i) => inlineCodes[i]);
  html = html.replace(/\u0000CB(\d+)\u0000/g, (m, i) => renderCodeBlock(codeBlocks[i].lang, codeBlocks[i].file, codeBlocks[i].code, i));

  html = html.replace(/(<\/h[1-4]>|<\/ul>|<\/ol>|<\/blockquote>|<hr>|<\/div>)<br>/g, "$1");
  html = html.replace(/<br>(<h[1-4]>|<ul>|<ol>|<blockquote>|<hr>|<div class="code-block")/g, "$1");

  return html;
}

function decodeCode(encoded) {
  try { return decodeURIComponent(escape(atob(encoded))); }
  catch (e) { return ""; }
}

function downloadText(text, fileName) {
  const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = fileName;
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 3000);
}

/* =========================================================
   CODE BLOCK HANDLER
========================================================= */
chatInner.addEventListener("click", (e) => {
  const copyBtn = e.target.closest(".cb-copy");
  const dlBtn = e.target.closest(".cb-download");

  if (copyBtn) {
    const block = copyBtn.closest(".code-block");
    if (!block) return;
    const code = decodeCode(block.dataset.code);
    navigator.clipboard.writeText(code).then(() => {
      copyBtn.classList.add("copied");
      const span = copyBtn.querySelector("span");
      const original = span.textContent;
      span.textContent = "Copied!";
      setTimeout(() => { copyBtn.classList.remove("copied"); span.textContent = original; }, 1500);
    }).catch(() => {});
  }

  if (dlBtn) {
    const block = dlBtn.closest(".code-block");
    if (!block) return;
    downloadText(decodeCode(block.dataset.code), block.dataset.file || "code.txt");
  }
});

/* =========================================================
   LIGHTBOX
========================================================= */
function openLightbox(src) { lightboxImg.src = src; lightbox.classList.add("show"); }
lightboxClose.addEventListener("click", () => lightbox.classList.remove("show"));
lightbox.addEventListener("click", (e) => { if (e.target === lightbox) lightbox.classList.remove("show"); });

/* =========================================================
   MODE SELECTOR
========================================================= */
function renderModeUI() {
  modeLabel.textContent = MODES[currentMode].name;
  document.querySelectorAll(".mode-item").forEach(el => {
    el.classList.toggle("active", el.dataset.mode === currentMode);
  });

  if (currentMode === "v2") {
    userInput.placeholder = "Deskripsikan gambar yang mau dibuat...";
  } else {
    userInput.placeholder = "Kirim pesan ke ZT AI...";
  }
}

function setMode(mode) {
  if (!MODES[mode]) return;
  currentMode = mode;
  localStorage.setItem(MODE_KEY, mode);
  renderModeUI();
}

modeBtn.addEventListener("click", (e) => { e.stopPropagation(); modeSelector.classList.toggle("open"); });
document.querySelectorAll(".mode-item").forEach(el => {
  el.addEventListener("click", (e) => {
    e.stopPropagation(); setMode(el.dataset.mode); modeSelector.classList.remove("open");
  });
});
document.addEventListener("click", (e) => {
  if (!modeSelector.contains(e.target)) modeSelector.classList.remove("open");
});

/* =========================================================
   STORAGE
========================================================= */
function loadChats() {
  try { chats = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); }
  catch { chats = []; }
}

function stripImageData(chat) {
  chat.messages.forEach(m => {
    if (m.type === "image" && typeof m.content === "string" && m.content.startsWith("blob:")) {
      m.content = "(Gambar sudah tidak tersedia)";
      m.type = "text";
    }
  });
  return chat;
}

function saveChats() {
  const chatsToSave = JSON.parse(JSON.stringify(chats));
  chatsToSave.forEach(stripImageData);

  let attempt = 0;
  const maxAttempts = 10;

  while (attempt < maxAttempts) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(chatsToSave));
      return;
    } catch (err) {
      if (err.name === "QuotaExceededError" || /quota/i.test(err.message)) {
        console.warn(`[Storage] Quota exceeded (attempt ${attempt + 1}). Menghapus chat paling lama...`);

        if (chatsToSave.length <= 1) {
          try { localStorage.removeItem(STORAGE_KEY); } catch (e) {}
          return;
        }

        chatsToSave.sort((a, b) => a.createdAt - b.createdAt);
        chatsToSave.shift();

        chats.sort((a, b) => a.createdAt - b.createdAt);
        const removed = chats.shift();
        if (removed && currentChatId === removed.id) {
          currentChatId = null;
          showWelcome();
          chatTitle.textContent = "New Chat";
        }
        renderHistory();
        attempt++;
      } else {
        console.error("[Storage] Save error:", err);
        return;
      }
    }
  }
}

function getCurrentChat() { return chats.find(c => c.id === currentChatId) || null; }

function renderHistory() {
  historyList.innerHTML = '<div class="history-label">Recent</div>';
  if (!chats.length) {
    const empty = document.createElement("div");
    empty.className = "history-empty";
    empty.textContent = "Belum ada riwayat";
    historyList.appendChild(empty);
    return;
  }
  const sorted = [...chats].sort((a,b) => b.createdAt - a.createdAt);
  sorted.forEach(c => {
    const item = document.createElement("div");
    item.className = "history-item" + (c.id === currentChatId ? " active" : "");
    item.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
      </svg>
      <span>${escapeHtml(c.title)}</span>
      <button class="del-btn" title="Hapus">×</button>
    `;
    item.querySelector("span").addEventListener("click", () => openChat(c.id));
    item.addEventListener("click", (e) => {
      if (e.target.closest(".del-btn")) return;
      openChat(c.id);
    });
    item.querySelector(".del-btn").addEventListener("click", (e) => {
      e.stopPropagation(); deleteChat(c.id);
    });
    historyList.appendChild(item);
  });
}

function deleteChat(id) {
  chats = chats.filter(c => c.id !== id);
  saveChats();
  if (currentChatId === id) { currentChatId = null; showWelcome(); chatTitle.textContent = "New Chat"; }
  renderHistory();
}

function newChat() {
  if (isGenerating) return;
  currentChatId = null; renderHistory(); showWelcome();
  chatTitle.textContent = "New Chat";
  userInput.focus();
  if (window.innerWidth <= 768) closeSidebar();
}

function openChat(id) {
  if (isGenerating) return;
  const chat = chats.find(c => c.id === id);
  if (!chat) return;
  currentChatId = id; chatTitle.textContent = chat.title;
  renderMessages(chat.messages); renderHistory();
  if (window.innerWidth <= 768) closeSidebar();
  scrollToBottom(false);
}

function showWelcome() {
  chatInner.innerHTML = "";
  chatInner.appendChild(welcome);
  welcome.style.display = "";
}

function renderMessages(messages) {
  chatInner.innerHTML = "";
  if (!messages.length) { showWelcome(); return; }
  messages.forEach(m => chatInner.appendChild(buildMessageEl(m.role, m.content, m.mode, m.type)));
}

/* =========================================================
   MESSAGE
========================================================= */
function buildMessageEl(role, content, mode, type) {
  const row = document.createElement("div");
  row.className = "msg-row " + (role === "user" ? "user" : "ai");

  const wrap = document.createElement("div");
  wrap.className = "bubble-wrap";

  const roleEl = document.createElement("div");
  roleEl.className = "msg-role";
  if (role === "user") {
    roleEl.textContent = "Anda";
  } else {
    const modeName = MODES[mode || currentMode]?.name || MODES[currentMode].name;
    roleEl.innerHTML = `ZT AI <span class="mode-tag">· ${escapeHtml(modeName)}</span>`;
  }

  if (role === "assistant" && type === "image") {
    const bubble = document.createElement("div");
    bubble.className = "bubble image-bubble";

    const img = document.createElement("img");
    img.src = content; img.alt = "Generated image"; img.loading = "lazy";
    img.addEventListener("click", () => openLightbox(content));
    img.addEventListener("error", () => {
      img.alt = "Gambar tidak tersedia";
      img.style.cssText = "padding: 20px; background: #1a1a1a; color: #666; font-size: 12px; text-align: center; min-width: 200px;";
    });
    bubble.appendChild(img);

    const actions = document.createElement("div");
    actions.className = "img-actions";

    const dlBtn = document.createElement("button");
    dlBtn.className = "img-btn";
    dlBtn.innerHTML = `${ICON_DL} Download`;
    dlBtn.addEventListener("click", async () => {
      try {
        dlBtn.disabled = true; dlBtn.innerHTML = `${ICON_DL} Loading...`;
        const resp = await fetch(content);
        let blob = await resp.blob();
        if (!blob.type.startsWith("image/")) blob = new Blob([blob], { type: "image/png" });
        const objectUrl = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = objectUrl; a.download = `zxx-tools-ai-${Date.now()}.png`;
        document.body.appendChild(a); a.click(); document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(objectUrl), 5000);
        dlBtn.innerHTML = `${ICON_DL} Download`; dlBtn.disabled = false;
      } catch (e) {
        dlBtn.innerHTML = `${ICON_DL} Download`; dlBtn.disabled = false;
      }
    });
    actions.appendChild(dlBtn);

    const openBtn = document.createElement("button");
    openBtn.className = "img-btn";
    openBtn.innerHTML = `${ICON_OPEN} Buka`;
    openBtn.addEventListener("click", () => {
      if (content.startsWith("blob:")) window.open(content, "_blank");
      else window.open(content, "_blank", "noopener");
    });
    actions.appendChild(openBtn);

    bubble.appendChild(actions);
    wrap.appendChild(roleEl); wrap.appendChild(bubble);
    row.appendChild(wrap);
    return row;
  }

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  if (role === "user") bubble.textContent = content;
  else bubble.innerHTML = parseMarkdown(content);

  wrap.appendChild(roleEl); wrap.appendChild(bubble);

  if (role === "assistant") {
    const actions = document.createElement("div");
    actions.className = "msg-actions";

    const copyBtn = document.createElement("button");
    copyBtn.className = "act-btn";
    copyBtn.innerHTML = `${ICON_COPY} Salin Pesan`;
    copyBtn.addEventListener("click", () => {
      navigator.clipboard.writeText(content);
      copyBtn.innerHTML = `${ICON_CHECK} Tersalin`;
      setTimeout(() => { copyBtn.innerHTML = `${ICON_COPY} Salin Pesan`; }, 1500);
    });
    actions.appendChild(copyBtn);

    const ttsBtn = document.createElement("button");
    ttsBtn.className = "act-btn tts-btn";
    ttsBtn.title = "Bacakan";
    ttsBtn.innerHTML = `
      <svg class="tts-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="12" height="12">
        <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>
        <path d="M15.54 8.46a5 5 0 0 1 0 7.07"/>
        <path d="M19.07 4.93a10 10 0 0 1 0 14.14"/>
      </svg>
      <span>Bacakan</span>
    `;
    ttsBtn.addEventListener("click", () => {
      TTS.speak(content, ttsBtn);
    });
    actions.appendChild(ttsBtn);

    wrap.appendChild(actions);
  }

  row.appendChild(wrap);
  return row;
}

function appendMessage(role, content, mode, type) {
  if (welcome.parentNode === chatInner) welcome.remove();
  const el = buildMessageEl(role, content, mode, type);
  chatInner.appendChild(el);
  scrollToBottom(true);
  return el;
}

function scrollToBottom(smooth = true) {
  requestAnimationFrame(() => {
    chatScroll.scrollTo({ top: chatScroll.scrollHeight, behavior: smooth ? "smooth" : "auto" });
  });
}

function createTypingEl(mode) {
  const row = document.createElement("div");
  row.className = "msg-row ai";
  const modeName = MODES[mode || currentMode]?.name || MODES[currentMode].name;
  row.innerHTML = `
    <div class="bubble-wrap">
      <div class="msg-role">ZT AI <span class="mode-tag">· ${escapeHtml(modeName)}</span></div>
      <div class="bubble typing-bubble"><div class="typing"><span></span><span></span><span></span></div></div>
    </div>`;
  return row;
}

function createImageLoaderEl(mode) {
  const row = document.createElement("div");
  row.className = "msg-row ai";
  const modeName = MODES[mode || currentMode]?.name || MODES[currentMode].name;
  row.innerHTML = `
    <div class="bubble-wrap">
      <div class="msg-role">ZT AI <span class="mode-tag">· ${escapeHtml(modeName)}</span></div>
      <div class="bubble image-bubble"><div class="img-loader"></div></div>
    </div>`;
  return row;
}

/* =========================================================
   PROMPT BUILDING
========================================================= */
function buildConversationHistory(messages) {
  if (!messages.length) return "";
  const recent = messages.slice(-4);
  let lines = [];
  recent.forEach(m => {
    if (m.type === "image") return;
    let content = m.content;
    if (typeof content !== "string") return;
    content = sanitizeIndonesian(content);
    if (content.length > 300) content = content.slice(0, 300) + "...";
    if (m.role === "user") lines.push(`U: ${content}`);
    else if (m.role === "assistant") lines.push(`A: ${content}`);
  });
  return lines.length ? lines.join("\n") + "\n" : "";
}

function buildLockedPrompt(historyMessages, userPrompt) {
  const historyBlock = buildConversationHistory(historyMessages);
  return `${SYSTEM_PROMPT}

INSTRUKSI WAJIB:
- Jawab sebagai ZT AI.
- Jangan ngaku AI/model lain.
- Creator: "NdizzXD".
- Jawab HANYA dalam BAHASA INDONESIA. BUKAN Melayu, BUKAN Malaysia, BUKAN Inggris.
- Kalau riwayat chat sebelumnya ada bahasa aneh (Melayu/Inggris), JANGAN TIRU. Tetap jawab Bahasa Indonesia.
- Tolak sopan hal berbahaya.
- Kalau kasih kode, WAJIB pakai format \`\`\`<bahasa>:<nama-file>.

${historyBlock}P: ${userPrompt}

A:`;
}

/* =========================================================
   API CALL
========================================================= */
async function fetchAI(historyMessages, userPrompt, mode, signal) {
  const cfg = MODES[mode] || MODES.v1;
  let url;
  if (cfg.type === "image") {
    url = `${cfg.base}?text=${encodeURIComponent(userPrompt)}`;
  } else {
    const lockedPrompt = buildLockedPrompt(historyMessages, userPrompt);
    url = `${cfg.base}?prompt=${encodeURIComponent(lockedPrompt)}`;
  }

  const res = await fetch(url, { method: "GET", headers: { "Accept": "*/*" }, signal });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);

  const contentType = (res.headers.get("content-type") || "").toLowerCase();

  if (contentType.startsWith("image/")) {
    const blob = await res.blob();
    const finalBlob = blob.type.startsWith("image/") ? blob : new Blob([blob], { type: "image/png" });
    return { type: "image", url: URL.createObjectURL(finalBlob), blob: finalBlob };
  }

  if (contentType.includes("octet-stream") || contentType === "") {
    const blob = await res.blob();
    const arr = new Uint8Array(await blob.slice(0, 4).arrayBuffer());
    const isJpeg = arr[0] === 0xFF && arr[1] === 0xD8;
    const isPng = arr[0] === 0x89 && arr[1] === 0x50;
    if (isJpeg || isPng) {
      const finalBlob = blob.type.startsWith("image/") ? blob : new Blob([blob], { type: isJpeg ? "image/jpeg" : "image/png" });
      return { type: "image", url: URL.createObjectURL(finalBlob), blob: finalBlob };
    }
    return parseTextResponse(await blob.text(), cfg);
  }

  return parseTextResponse(await res.text(), cfg);
}

function parseTextResponse(text, cfg) {
  try {
    const data = JSON.parse(text);
    return cfg.parse(data);
  } catch (e) {
    const urlMatch = text.match(/https?:\/\/\S+\.(png|jpe?g|webp|gif|bmp)(\?\S*)?/i);
    if (urlMatch) return { type: "image", url: urlMatch[0] };
    if (cfg.type === "text") return { type: "text", text: text };
    throw new Error(text.slice(0, 200) || "Respons gak dikenali");
  }
}

/* =========================================================
   TYPEWRITER
========================================================= */
async function typewriter(el, text, signal) {
  el.innerHTML = "";
  const cursor = document.createElement("span");
  cursor.className = "cursor-blk";
  el.appendChild(cursor);

  const chars = [...text];
  const total = chars.length;
  const baseDelay = total > 800 ? 2 : total > 400 ? 4 : total > 150 ? 8 : 12;

  let buffer = ""; let lastRender = 0;
  for (let i = 0; i < total; i++) {
    if (signal.aborted) { cursor.remove(); break; }
    buffer += chars[i];
    if (i - lastRender >= 8 || i === total - 1) {
      el.innerHTML = parseMarkdown(buffer);
      el.appendChild(cursor);
      lastRender = i;
      if (i % 40 === 0) scrollToBottom(false);
    }
    if (chars[i] !== " " && chars[i] !== "\n") {
      await new Promise(r => setTimeout(r, baseDelay));
    }
  }
  cursor.remove();
  el.innerHTML = parseMarkdown(sanitizeIndonesian(text));
  scrollToBottom(true);
}

/* =========================================================
   SEND MESSAGE
========================================================= */
async function sendMessage() {
  const text = userInput.value.trim();
  if (!text || isGenerating) return;

  const usedMode = currentMode;
  const modeCfg = MODES[usedMode];

  let chat = getCurrentChat();
  if (!chat) {
    chat = { id: uid(), title: text.slice(0, 40) + (text.length > 40 ? "..." : ""), messages: [], createdAt: Date.now() };
    chats.push(chat); currentChatId = chat.id;
    chatTitle.textContent = chat.title; renderHistory();
  }

  if (welcome.parentNode === chatInner) welcome.remove();
  const historyForAI = [...chat.messages];

  chat.messages.push({ role: "user", content: text, type: "text" });
  appendMessage("user", text, usedMode, "text");
  saveChats();

  userInput.value = "";
  autoResize();
  updateSendBtn();
  setGenerating(true);

  const loaderEl = modeCfg.type === "image" ? createImageLoaderEl(usedMode) : createTypingEl(usedMode);
  chatInner.appendChild(loaderEl);
  scrollToBottom(true);

  try {
    abortController = new AbortController();
    const result = await fetchAI(historyForAI, text, usedMode, abortController.signal);
    loaderEl.remove();

    if (result.type === "image") {
      appendMessage("assistant", result.url, usedMode, "image");
      chat.messages.push({ role: "assistant", content: result.url, mode: usedMode, type: "image" });
      saveChats(); scrollToBottom(true);
    } else {
      const cleaned = sanitizeIndonesian(result.text);
      const aiEl = appendMessage("assistant", "", usedMode, "text");
      const bubbleEl = aiEl.querySelector(".bubble");
      await typewriter(bubbleEl, cleaned, abortController.signal);
      chat.messages.push({ role: "assistant", content: cleaned, mode: usedMode, type: "text" });
      saveChats();
    }
  } catch (err) {
    loaderEl.remove();
    if (err.name === "AbortError") {
      const stopped = "(Dihentikan oleh pengguna)";
      appendMessage("assistant", stopped, usedMode, "text");
      chat.messages.push({ role: "assistant", content: stopped, mode: usedMode, type: "text" });
    } else {
      const errMsg = "Maaf, terjadi kesalahan: " + err.message;
      appendMessage("assistant", errMsg, usedMode, "text");
      chat.messages.push({ role: "assistant", content: errMsg, mode: usedMode, type: "text" });
    }
    saveChats();
  } finally {
    setGenerating(false);
    abortController = null;
    userInput.focus();
  }
}

function setGenerating(on) {
  isGenerating = on;
  sendBtn.disabled = on || !userInput.value.trim();
  sendBtn.innerHTML = on ? ICON_STOP : ICON_SEND;
  sendBtn.title = on ? "Stop" : "Kirim";
}
function updateSendBtn() { if (isGenerating) return; sendBtn.disabled = !userInput.value.trim(); }
function autoResize() { userInput.style.height = "auto"; userInput.style.height = Math.min(userInput.scrollHeight, 120) + "px"; }

userInput.addEventListener("input", () => { autoResize(); updateSendBtn(); });
userInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    if (isGenerating) stopGeneration(); else sendMessage();
  }
});

sendBtn.addEventListener("click", () => { if (isGenerating) stopGeneration(); else sendMessage(); });
function stopGeneration() { if (abortController) abortController.abort(); }

function openSidebar() {
  sidebar.classList.remove("collapsed");
  if (window.innerWidth <= 768) overlay.classList.add("show");
}
function closeSidebar() {
  sidebar.classList.add("collapsed"); overlay.classList.remove("show");
}
toggleBtn.addEventListener("click", () => {
  if (sidebar.classList.contains("collapsed")) openSidebar(); else closeSidebar();
});
overlay.addEventListener("click", closeSidebar);
newChatBtn.addEventListener("click", newChat);

document.querySelectorAll(".suggestion").forEach(el => {
  el.addEventListener("click", () => {
    userInput.value = el.dataset.prompt;
    autoResize(); updateSendBtn(); sendMessage();
  });
});

/* =========================================================
   KEYBOARD FIX
========================================================= */
function setAppSize() {
  const vv = window.visualViewport;
  const h = vv ? Math.round(vv.height) : window.innerHeight;
  const top = vv ? Math.round(vv.offsetTop) : 0;
  app.style.height = h + "px";
  app.style.top = top + "px";
  if (window.scrollY !== 0) window.scrollTo(0, 0);
}
function keepInputVisible() {
  setAppSize();
  try { inputArea.scrollIntoView({ block: "end", behavior: "instant" }); }
  catch (e) { inputArea.scrollIntoView(false); }
  requestAnimationFrame(() => scrollToBottom(false));
}
function setupKeyboardFix() {
  setAppSize();
  if (window.visualViewport) {
    window.visualViewport.addEventListener("resize", setAppSize);
    window.visualViewport.addEventListener("scroll", setAppSize);
  }
  window.addEventListener("resize", setAppSize);
  window.addEventListener("orientationchange", () => {
    setTimeout(setAppSize, 100); setTimeout(setAppSize, 300); setTimeout(setAppSize, 600);
  });
  let lastH = 0, lastTop = 0;
  setInterval(() => {
    const vv = window.visualViewport;
    const h = vv ? Math.round(vv.height) : window.innerHeight;
    const t = vv ? Math.round(vv.offsetTop) : 0;
    if (h !== lastH || t !== lastTop) {
      lastH = h; lastTop = t;
      setAppSize();
      requestAnimationFrame(() => scrollToBottom(false));
    }
  }, 150);
  userInput.addEventListener("focus", () => {
    [0, 50, 100, 200, 300, 500, 800, 1200, 1600].forEach(t => setTimeout(keepInputVisible, t));
  });
  userInput.addEventListener("blur", () => {
    [100, 300, 600].forEach(t => setTimeout(setAppSize, t));
  });
  inputArea.addEventListener("click", () => {
    [0, 100, 300, 500].forEach(t => setTimeout(keepInputVisible, t));
  });
}

/* =========================================================
   INIT
========================================================= */
function init() {
  loadChats(); renderHistory(); renderModeUI(); showWelcome();
  autoResize(); setupKeyboardFix();
  if (window.innerWidth <= 768) sidebar.classList.add("collapsed");
}

window.addEventListener("resize", () => {
  if (window.innerWidth > 768) overlay.classList.remove("show");
});

init();