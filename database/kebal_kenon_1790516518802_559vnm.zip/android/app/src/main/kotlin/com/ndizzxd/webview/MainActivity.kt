package com.ndizzxd.webview

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}