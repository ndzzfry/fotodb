const express = require('express');
const axios = require('axios');

const app = express();
app.use(express.json());

// ============================================
//  CONFIGURATION
// ============================================
const SECRET_KEY = process.env.API_SECRET_KEY || 'default-key-change-me-in-vercel';
const RATE_LIMIT_MAX = parseInt(process.env.RATE_LIMIT_MAX) || 20;
const RATE_LIMIT_WINDOW = parseInt(process.env.RATE_LIMIT_WINDOW) || 60000;

// ============================================
//  RATE LIMITER
// ============================================
const requestLog = new Map();

function checkRateLimit(ip) {
    const now = Date.now();
    if (!requestLog.has(ip)) {
        requestLog.set(ip, []);
    }
    const timestamps = requestLog.get(ip).filter(t => t > now - RATE_LIMIT_WINDOW);
    timestamps.push(now);
    requestLog.set(ip, timestamps);
    return timestamps.length <= RATE_LIMIT_MAX;
}

// ============================================
//  MIDDLEWARE: CORS
// ============================================
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type, X-API-Key, Authorization');
    if (req.method === 'OPTIONS') return res.sendStatus(200);
    next();
});

// ============================================
//  MIDDLEWARE: API KEY VERIFICATION
// ============================================
function verifyApiKey(req, res, next) {
    // Kecuali untuk route /api/key (public)
    if (req.path === '/api/key') {
        return next();
    }

    const apiKey = req.headers['x-api-key'] || req.headers['authorization'];
    
    if (!apiKey) {
        return res.status(401).json({ 
            error: 'API Key diperlukan',
            hint: 'Kirim dengan header: x-api-key'
        });
    }
    
    if (apiKey !== SECRET_KEY) {
        return res.status(403).json({ 
            error: 'API Key tidak valid' 
        });
    }
    
    next();
}

// ============================================
//  MIDDLEWARE: RATE LIMIT
// ============================================
function rateLimitMiddleware(req, res, next) {
    const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown';
    if (!checkRateLimit(ip)) {
        return res.status(429).json({ 
            error: 'Terlalu banyak request. Tunggu sebentar.' 
        });
    }
    next();
}

// ============================================
//  APPLY MIDDLEWARE
// ============================================
app.use('/api/', verifyApiKey);
app.use('/api/', rateLimitMiddleware);

// ============================================
//  ROUTE: GET API KEY (PUBLIC)
// ============================================
app.get('/api/key', (req, res) => {
    // Kirim key yang sudah di-obfuscate
    const key = SECRET_KEY;
    // Split jadi 2 bagian untuk keamanan frontend
    const half = Math.ceil(key.length / 2);
    res.json({
        part1: key.substring(0, half),
        part2: key.substring(half),
        hint: 'Gabungkan kedua bagian untuk mendapatkan API Key'
    });
});

// ============================================
//  ROUTE: HEALTH CHECK
// ============================================
app.get('/api/health', (req, res) => {
    res.json({ 
        status: 'ok', 
        timestamp: Date.now(),
        uptime: process.uptime()
    });
});

// ============================================
//  ROUTE: EXTRACT SINGLE
// ============================================
app.get('/api/extract', async (req, res) => {
    try {
        const url = req.query.url;
        if (!url) {
            return res.status(400).json({ error: 'URL diperlukan' });
        }
        if (!url.includes('tiktok.com')) {
            return res.status(400).json({ error: 'URL tidak valid, harus link TikTok' });
        }

        const response = await axios.get(`https://www.tikwm.com/api/?url=${encodeURIComponent(url)}`, {
            timeout: 20000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': 'application/json'
            }
        });

        const data = response.data;
        if (data.code !== 0 || !data.data) {
            return res.status(404).json({ error: data.msg || 'Data tidak ditemukan' });
        }

        const d = data.data;
        res.json({
            success: true,
            video: d.play || null,
            music: d.music || null,
            images: (d.images && Array.isArray(d.images)) ? d.images : [],
            title: d.title || '',
            author: d.author || {},
            cover: d.cover || null,
            duration: d.duration || 0,
            wmVideo: d.wmplay || null,
            hdVideo: d.hdplay || null
        });

    } catch (error) {
        console.error('Extract error:', error.message);
        res.status(500).json({ 
            error: 'Gagal mengambil data', 
            details: error.message 
        });
    }
});

// ============================================
//  ROUTE: BATCH EXTRACT
// ============================================
app.post('/api/batch', async (req, res) => {
    try {
        const { urls } = req.body;
        if (!urls || !Array.isArray(urls) || urls.length === 0) {
            return res.status(400).json({ error: 'URLs array diperlukan' });
        }
        if (urls.length > 10) {
            return res.status(400).json({ error: 'Maksimal 10 URL' });
        }

        const results = [];
        for (let i = 0; i < urls.length; i++) {
            const url = urls[i].trim();
            if (!url) continue;

            if (!url.includes('tiktok.com')) {
                results.push({ index: i, url, error: 'URL tidak valid' });
                continue;
            }

            try {
                const response = await axios.get(`https://www.tikwm.com/api/?url=${encodeURIComponent(url)}`, {
                    timeout: 15000,
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                    }
                });

                const data = response.data;
                if (data.code !== 0 || !data.data) {
                    results.push({ index: i, url, error: data.msg || 'Data tidak ditemukan' });
                    continue;
                }

                const d = data.data;
                results.push({
                    index: i,
                    url,
                    success: true,
                    video: d.play || null,
                    music: d.music || null,
                    images: (d.images && Array.isArray(d.images)) ? d.images : [],
                    title: d.title || '',
                    author: d.author || {}
                });

            } catch (e) {
                results.push({ index: i, url, error: 'Gagal memproses link ini' });
            }
        }

        res.json({ results });

    } catch (error) {
        console.error('Batch error:', error.message);
        res.status(500).json({ error: 'Gagal memproses batch' });
    }
});

// ============================================
//  ROUTE: PROXY DOWNLOAD
// ============================================
app.get('/api/download', async (req, res) => {
    try {
        const url = req.query.url;
        if (!url) {
            return res.status(400).json({ error: 'URL diperlukan' });
        }

        const response = await axios({
            method: 'GET',
            url: url,
            responseType: 'stream',
            timeout: 30000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Referer': 'https://www.tiktok.com/'
            }
        });

        const contentDisposition = response.headers['content-disposition'] || 
                                  `attachment; filename="download_${Date.now()}.mp4"`;
        
        res.setHeader('Content-Disposition', contentDisposition);
        res.setHeader('Content-Type', response.headers['content-type'] || 'application/octet-stream');
        res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
        
        response.data.pipe(res);

    } catch (error) {
        console.error('Download error:', error.message);
        res.status(500).json({ error: 'Gagal mengunduh file' });
    }
});

// ============================================
//  SERVE FRONTEND
// ============================================
const path = require('path');
app.use(express.static(path.join(__dirname, '../public')));

app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/index.html'));
});

// ============================================
//  EXPORT FOR VERCEL
// ============================================
module.exports = app;

// ============================================
//  LOCAL DEVELOPMENT
// ============================================
if (require.main === module) {
    const PORT = process.env.PORT || 3000;
    app.listen(PORT, () => {
        console.log(`🚀 Server running on http://localhost:${PORT}`);
        console.log(`🔑 API Key: ${SECRET_KEY.substring(0, 10)}...`);
    });
}