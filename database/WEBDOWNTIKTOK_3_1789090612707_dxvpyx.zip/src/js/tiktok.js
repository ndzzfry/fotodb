// ============================================================
//  TIKTOK.JS — Full Downloader Logic with Security
// ============================================================

document.addEventListener('DOMContentLoaded', function() {
    
    // ===== DOM REFS =====
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = {
        tiktok: document.getElementById('tabTiktok'),
        instagram: document.getElementById('tabInstagram'),
        allinone: document.getElementById('tabAllinone')
    };
    const urlGroup = document.getElementById('urlGroup');
    const countBtns = document.querySelectorAll('#countBtnGroup .count-btn');
    const processBtn = document.getElementById('processBtn');
    const resultPanel = document.getElementById('resultPanel');
    const igProcessBtn = document.getElementById('igProcessBtn');
    const igResult = document.getElementById('igResult');
    const igInput = document.getElementById('igInput');
    const igClear = document.getElementById('igClear');
    const allProcessBtn = document.getElementById('allProcessBtn');
    const allResult = document.getElementById('allResult');
    const allInput = document.getElementById('allInput');
    const allClear = document.getElementById('allClear');
    const clearHistoryBtn = document.getElementById('clearHistory');
    const loadingOverlay = document.getElementById('loadingOverlay');
    const loadingSub = document.getElementById('loadingSub');

    // ===== TAB SWITCH =====
    tabBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            tabBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            const tab = this.dataset.tab;
            Object.keys(tabContents).forEach(key => {
                tabContents[key].classList.toggle('active', key === tab);
            });
            if (tab === 'instagram') igResult.innerHTML = '';
            if (tab === 'allinone') allResult.innerHTML = '';
        });
    });

    // ===== BUILD INPUTS =====
    function buildInputs(count) {
        urlGroup.innerHTML = '';
        for (let i = 0; i < count; i++) {
            const div = document.createElement('div');
            div.className = 'url-item';
            div.innerHTML = `
                <span class="idx">${i + 1}</span>
                <input type="text" placeholder="Tempel link TikTok ${i + 1}" class="url-field" data-idx="${i}">
                <span class="status-icon" id="status_${i}"><i class="fas fa-circle" style="font-size:0.4rem;"></i></span>
                <span class="clear-btn"><i class="fas fa-times-circle"></i></span>
                <div class="preview-container" id="preview_${i}"></div>
            `;
            urlGroup.appendChild(div);
            
            const input = div.querySelector('input');
            const clear = div.querySelector('.clear-btn');
            const statusEl = document.getElementById(`status_${i}`);
            const previewEl = document.getElementById(`preview_${i}`);
            
            input.addEventListener('input', function() {
                const val = this.value.trim();
                if (val && val.includes('tiktok.com')) {
                    window.addToHistory({ url: val, type: 'TikTok', hasVideo: false, hasAudio: false, hasImages: false });
                    autoPreview(i, val);
                } else if (val) {
                    statusEl.innerHTML = '<i class="fas fa-exclamation-triangle"></i>';
                    statusEl.className = 'status-icon error';
                    previewEl.classList.remove('show');
                    previewEl.innerHTML = '';
                } else {
                    statusEl.innerHTML = '<i class="fas fa-circle" style="font-size:0.4rem;"></i>';
                    statusEl.className = 'status-icon';
                    previewEl.classList.remove('show');
                    previewEl.innerHTML = '';
                }
            });
            
            clear.addEventListener('click', function() {
                const url = input.value.trim();
                if (url) {
                    const history = window.getHistory();
                    const filtered = history.filter(h => h.url !== url);
                    window.saveHistory(filtered);
                    window.renderHistory();
                }
                input.value = '';
                previewEl.classList.remove('show');
                previewEl.innerHTML = '';
                statusEl.innerHTML = '<i class="fas fa-circle" style="font-size:0.4rem;"></i>';
                statusEl.className = 'status-icon';
            });
            
            input.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    processBtn.click();
                }
            });
        }
        if (urlGroup.querySelector('.url-field')) {
            setTimeout(() => urlGroup.querySelector('.url-field').focus(), 150);
        }
    }

    // ===== AUTO PREVIEW =====
    const previewTimers = {};
    
    async function autoPreview(idx, url) {
        const statusEl = document.getElementById(`status_${idx}`);
        const previewEl = document.getElementById(`preview_${idx}`);
        
        if (previewTimers[idx]) clearTimeout(previewTimers[idx]);
        
        statusEl.innerHTML = '<i class="fas fa-spinner"></i>';
        statusEl.className = 'status-icon loading';
        previewEl.classList.remove('show');
        previewEl.innerHTML = '';
        
        previewTimers[idx] = setTimeout(async function() {
            try {
                const apiUrl = 'https://www.tikwm.com/api/?url=' + encodeURIComponent(url);
                const resp = await fetch(apiUrl);
                const json = await resp.json();
                
                if (json.code !== 0 || !json.data) {
                    statusEl.innerHTML = '<i class="fas fa-times"></i>';
                    statusEl.className = 'status-icon error';
                    previewEl.innerHTML = `<div class="preview-error"><i class="fas fa-exclamation-circle"></i> ${json.msg || 'Data tidak ditemukan'}</div>`;
                    previewEl.classList.add('show');
                    return;
                }
                
                const data = json.data;
                let html = '';
                let hasContent = false;
                
                if (data.play) {
                    html += `<div class="preview-label"><i class="fas fa-film"></i> Video Preview</div>`;
                    html += `<video controls src="${data.play}" preload="metadata"></video>`;
                    html += `<button class="dl-preview-btn" data-url="${data.play}" data-name="video_${idx+1}.mp4"><i class="fas fa-download"></i> Download Video</button>`;
                    hasContent = true;
                }
                
                if (data.music) {
                    if (hasContent) html += '<div style="margin-top:8px;"></div>';
                    html += `<div class="preview-label"><i class="fas fa-headphones"></i> Audio Preview</div>`;
                    html += `<audio controls src="${data.music}" preload="metadata"></audio>`;
                    html += `<button class="dl-preview-btn" data-url="${data.music}" data-name="audio_${idx+1}.mp3"><i class="fas fa-download"></i> Download Audio</button>`;
                    hasContent = true;
                }
                
                if (data.images && Array.isArray(data.images) && data.images.length > 0) {
                    if (hasContent) html += '<div style="margin-top:8px;"></div>';
                    html += `<div class="preview-label"><i class="fas fa-images"></i> Foto Preview (${data.images.length})</div>`;
                    html += '<div class="photo-grid">';
                    data.images.forEach((img, i2) => {
                        html += `<img src="${img}" alt="Foto ${i2+1}" loading="lazy" data-url="${img}" data-name="img_${idx+1}_${i2+1}.jpg">`;
                    });
                    html += '</div>';
                    hasContent = true;
                }
                
                if (!hasContent) {
                    statusEl.innerHTML = '<i class="fas fa-times"></i>';
                    statusEl.className = 'status-icon error';
                    previewEl.innerHTML = '<div class="preview-error"><i class="fas fa-exclamation-circle"></i> Tidak ada konten</div>';
                    previewEl.classList.add('show');
                    return;
                }
                
                statusEl.innerHTML = '<i class="fas fa-check"></i>';
                statusEl.className = 'status-icon success';
                previewEl.innerHTML = html;
                previewEl.classList.add('show');
                
                previewEl.querySelectorAll('.dl-preview-btn').forEach(btn => {
                    btn.addEventListener('click', function(e) {
                        e.stopPropagation();
                        window.secureDownload(this.dataset.url, this.dataset.name);
                    });
                });
                
                previewEl.querySelectorAll('.photo-grid img').forEach(img => {
                    img.addEventListener('click', function() {
                        window.secureDownload(this.dataset.url, this.dataset.name);
                    });
                });
                
            } catch (err) {
                statusEl.innerHTML = '<i class="fas fa-times"></i>';
                statusEl.className = 'status-icon error';
                previewEl.innerHTML = `<div class="preview-error"><i class="fas fa-exclamation-circle"></i> Gagal mengambil preview</div>`;
                previewEl.classList.add('show');
            }
        }, 600);
    }

    // ===== EXTRACT SINGLE =====
    async function extractSingle(url) {
        try {
            const apiUrl = 'https://www.tikwm.com/api/?url=' + encodeURIComponent(url);
            const resp = await fetch(apiUrl);
            const json = await resp.json();
            if (json.code !== 0 || !json.data) {
                return { error: json.msg || 'Data tidak ditemukan' };
            }
            const data = json.data;
            return {
                video: data.play || null,
                music: data.music || null,
                images: (data.images && Array.isArray(data.images)) ? data.images : []
            };
        } catch (e) {
            return { error: 'Koneksi gagal' };
        }
    }

    // ===== PROCESS ALL (TikTok) =====
    processBtn.addEventListener('click', async function() {
        const inputs = urlGroup.querySelectorAll('.url-field');
        const links = [];
        inputs.forEach(inp => {
            const val = inp.value.trim();
            if (val) links.push(val);
        });
        
        if (links.length === 0) {
            window.showNotification('warning', 'Link kosong', 'Isi minimal satu link TikTok.', 3000);
            return;
        }
        
        for (let link of links) {
            if (!link.includes('tiktok.com')) {
                window.showNotification('error', 'Link tidak valid', 'Harap masukkan link TikTok yang valid.', 3000);
                return;
            }
        }
        
        const btnLabel = document.getElementById('btnLabel');
        const btnSpin = document.getElementById('btnSpin');
        
        btnLabel.style.opacity = '0';
        btnSpin.style.display = 'inline-block';
        resultPanel.style.display = 'none';
        resultPanel.innerHTML = '';
        window.showNotification('info', 'Memproses', `Mengambil data dari ${links.length} link...`, 2000);
        
        const allResults = [];
        let hasError = false;
        for (let i = 0; i < links.length; i++) {
            loadingSub.textContent = `Memproses link ${i+1} dari ${links.length}`;
            const res = await extractSingle(links[i]);
            allResults.push({ idx: i, url: links[i], data: res });
            if (res.error) hasError = true;
        }
        
        let html = '';
        for (let j = 0; j < allResults.length; j++) {
            const item = allResults[j];
            const d = item.data;
            if (d.error) {
                html += `<div class="result-item" style="border-color:rgba(255,77,77,0.2);"><div class="meta"><span class="idx">Link ${j+1}</span><span style="color:#ff4d4d;">Gagal</span></div><div style="font-size:0.8rem;color:#7a7a7a;">${d.error}</div></div>`;
                continue;
            }
            
            let rowHtml = '';
            const hasVideo = !!d.video;
            const hasAudio = !!d.music;
            const hasImages = d.images && d.images.length > 0;
            
            const history = window.getHistory();
            const existing = history.findIndex(h => h.url === item.url);
            if (existing !== -1) {
                history[existing].hasVideo = hasVideo;
                history[existing].hasAudio = hasAudio;
                history[existing].hasImages = hasImages;
                window.saveHistory(history);
                window.renderHistory();
            }
            
            if (hasVideo) {
                rowHtml += `<div class="dl-row" data-video="${d.video}" data-name="video_${j+1}.mp4"><div class="dl-left"><i class="fas fa-film"></i><span>Video No WM</span></div><i class="fas fa-arrow-down dl-arrow"></i></div>`;
            }
            if (hasAudio) {
                rowHtml += `<div class="dl-row" data-music="${d.music}" data-name="audio_${j+1}.mp3"><div class="dl-left"><i class="fas fa-headphones"></i><span>Audio</span></div><i class="fas fa-arrow-down dl-arrow"></i></div>`;
            }
            if (hasImages) {
                let photoHtml = '<div class="photo-stack">';
                d.images.forEach((img, idx2) => {
                    photoHtml += `<div class="photo-item" data-img="${img}" data-name="img_${j+1}_${idx2+1}.jpg"><i class="far fa-image"></i><span>Foto ${idx2+1}</span><i class="fas fa-download" style="margin-left:6px;font-size:0.7rem;"></i></div>`;
                });
                photoHtml += '</div>';
                rowHtml += photoHtml;
            }
            if (!rowHtml) {
                rowHtml = '<div style="font-size:0.8rem;color:#6a6a6a;padding:8px 0;">Tidak ada konten</div>';
            }
            html += `<div class="result-item"><div class="meta"><span class="idx">Link ${j+1}</span><span style="color:#6a6a6a;font-size:0.75rem;">${hasVideo ? 'Video' : ''}${hasAudio ? ' Audio' : ''}${hasImages ? ' Foto' : ''}</span></div>${rowHtml}</div>`;
        }
        
        resultPanel.innerHTML = html;
        resultPanel.style.display = 'block';
        
        resultPanel.querySelectorAll('.dl-row[data-video]').forEach(el => {
            el.addEventListener('click', function(e) {
                e.stopPropagation();
                window.secureDownload(this.dataset.video, this.dataset.name);
            });
        });
        resultPanel.querySelectorAll('.dl-row[data-music]').forEach(el => {
            el.addEventListener('click', function(e) {
                e.stopPropagation();
                window.secureDownload(this.dataset.music, this.dataset.name);
            });
        });
        resultPanel.querySelectorAll('.photo-item[data-img]').forEach(el => {
            el.addEventListener('click', function(e) {
                e.stopPropagation();
                window.secureDownload(this.dataset.img, this.dataset.name);
            });
        });
        
        btnLabel.style.opacity = '1';
        btnSpin.style.display = 'none';
        loadingSub.textContent = 'Selesai';
        setTimeout(() => { loadingSub.textContent = 'Mohon tunggu'; }, 800);
        
        if (hasError) {
            window.showNotification('warning', 'Beberapa gagal', 'Cek link yang error dan coba lagi.', 4000);
        } else {
            window.showNotification('success', 'Selesai', 'Semua link siap diunduh.', 3000);
        }
    });

    // ===== COUNT BUTTONS =====
    countBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            countBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            const count = parseInt(this.dataset.count, 10);
            buildInputs(count);
            resultPanel.style.display = 'none';
            resultPanel.innerHTML = '';
        });
    });

    // ===== INSTAGRAM =====
    igClear.addEventListener('click', function() {
        const url = igInput.value.trim();
        if (url) {
            const history = window.getHistory();
            const filtered = history.filter(h => h.url !== url);
            window.saveHistory(filtered);
            window.renderHistory();
        }
        igInput.value = '';
        igResult.innerHTML = '';
        igInput.focus();
    });

    igInput.addEventListener('input', function() {
        const val = this.value.trim();
        if (val && val.includes('instagram.com')) {
            window.addToHistory({ url: val, type: 'Instagram', hasVideo: false, hasAudio: false, hasImages: false });
        }
    });

    igInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            igProcessBtn.click();
        }
    });

    igProcessBtn.addEventListener('click', async function() {
        const url = igInput.value.trim();
        if (!url) {
            window.showNotification('warning', 'Link kosong', 'Masukkan link Instagram terlebih dahulu.', 3000);
            return;
        }
        if (!url.includes('instagram.com')) {
            window.showNotification('error', 'Link tidak valid', 'Harap masukkan link Instagram yang valid.', 3000);
            return;
        }
        
        const btnLabel = document.getElementById('igBtnLabel');
        const btnSpin = document.getElementById('igBtnSpin');
        
        btnLabel.style.opacity = '0';
        btnSpin.style.display = 'inline-block';
        igResult.innerHTML = '';
        
        try {
            const apiUrl = 'https://api.ikyyxd.my.id/download/igv2?url=' + encodeURIComponent(url);
            const resp = await fetch(apiUrl);
            const data = await resp.json();
            
            if (data.status === true && data.result && data.result.length > 0) {
                const results = data.result;
                let hasVideo = false;
                let hasImages = false;
                const mediaItems = [];
                
                results.forEach(item => {
                    const mediaUrl = item.url;
                    const size = item.size || 'Unknown';
                    const isVideo = mediaUrl && (mediaUrl.includes('.mp4') || mediaUrl.includes('video') || mediaUrl.includes('/video/'));
                    const isImage = mediaUrl && (mediaUrl.includes('.jpg') || mediaUrl.includes('.jpeg') || mediaUrl.includes('.png') || mediaUrl.includes('.webp'));
                    
                    if (isVideo) {
                        hasVideo = true;
                        mediaItems.push({ type: 'video', url: mediaUrl, size: size });
                    } else if (isImage) {
                        hasImages = true;
                        mediaItems.push({ type: 'image', url: mediaUrl, size: size });
                    } else {
                        hasImages = true;
                        mediaItems.push({ type: 'image', url: mediaUrl, size: size });
                    }
                });
                
                const history = window.getHistory();
                const existing = history.findIndex(h => h.url === url);
                if (existing !== -1) {
                    history[existing].hasVideo = hasVideo;
                    history[existing].hasImages = hasImages;
                    history[existing].type = 'Instagram';
                    window.saveHistory(history);
                    window.renderHistory();
                }
                
                let html = '<div class="ig-item">';
                html += `<div class="ig-meta"><i class="fas fa-image" style="margin-right:6px;"></i> ${data.total} media ditemukan</div>`;
                html += `<div class="ig-meta"><i class="fas fa-code" style="margin-right:6px;"></i> Creator: ${data.creator || 'IkyyOfficiall'}</div>`;
                
                mediaItems.forEach((media, idx) => {
                    const fileName = `instagram_${idx+1}.${media.type === 'video' ? 'mp4' : 'jpg'}`;
                    
                    if (media.type === 'video') {
                        html += `<video class="ig-media" controls src="${media.url}" preload="metadata"></video>`;
                    } else {
                        html += `<img class="ig-media" src="${media.url}" alt="Media ${idx+1}" loading="lazy">`;
                    }
                    
                    html += `<div style="margin-top:6px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;">`;
                    html += `<span style="font-size:0.7rem;color:#6a6a6a;"><i class="fas fa-file"></i> ${media.size}</span>`;
                    html += `<button class="ig-dl-btn" data-url="${media.url}" data-name="${fileName}"><i class="fas fa-download"></i> Download ${media.type === 'video' ? 'Video' : 'Foto'} ${idx+1}</button>`;
                    html += `</div>`;
                });
                
                html += '</div>';
                igResult.innerHTML = html;
                
                igResult.querySelectorAll('.ig-dl-btn').forEach(btn => {
                    btn.addEventListener('click', function() {
                        window.secureDownload(this.dataset.url, this.dataset.name);
                    });
                });
                
                window.showNotification('success', '🔥 NdizzXD', 'Wah User Download Instagram NdizzXD Muncul Nieh Hormat Grak!', 5000);
                
            } else {
                const errMsg = data.message || data.msg || 'Gagal mengambil data Instagram.';
                igResult.innerHTML = `<div class="ig-item"><div class="ig-error"><i class="fas fa-exclamation-circle"></i> ${errMsg}</div></div>`;
                window.showNotification('error', 'Gagal', errMsg, 3000);
            }
        } catch (err) {
            console.error('IG Error:', err);
            igResult.innerHTML = `<div class="ig-item"><div class="ig-error"><i class="fas fa-exclamation-circle"></i> Error: ${err.message}</div></div>`;
            window.showNotification('error', 'Gagal', 'Terjadi kesalahan: ' + err.message, 3000);
        } finally {
            btnLabel.style.opacity = '1';
            btnSpin.style.display = 'none';
        }
    });

    // ===== ALL-IN-ONE =====
    allClear.addEventListener('click', function() {
        const url = allInput.value.trim();
        if (url) {
            const history = window.getHistory();
            const filtered = history.filter(h => h.url !== url);
            window.saveHistory(filtered);
            window.renderHistory();
        }
        allInput.value = '';
        allResult.innerHTML = '';
        allInput.focus();
    });

    allInput.addEventListener('input', function() {
        const val = this.value.trim();
        if (val && (val.includes('instagram.com') || val.includes('tiktok.com') || val.includes('youtube.com') || val.includes('facebook.com') || val.includes('twitter.com'))) {
            window.addToHistory({ url: val, type: 'All-in-One', hasVideo: false, hasAudio: false, hasImages: false });
        }
    });

    allInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            allProcessBtn.click();
        }
    });

    allProcessBtn.addEventListener('click', async function() {
        const url = allInput.value.trim();
        if (!url) {
            window.showNotification('warning', 'Link kosong', 'Masukkan link terlebih dahulu.', 3000);
            return;
        }
        
        const btnLabel = document.getElementById('allBtnLabel');
        const btnSpin = document.getElementById('allBtnSpin');
        
        btnLabel.style.opacity = '0';
        btnSpin.style.display = 'inline-block';
        allResult.innerHTML = '';
        
        try {
            let platform = 'unknown';
            let apiUrl = '';
            
            if (url.includes('instagram.com')) {
                platform = 'Instagram';
                apiUrl = 'https://api.ikyyxd.my.id/download/igv2?url=' + encodeURIComponent(url);
            } else if (url.includes('tiktok.com')) {
                platform = 'TikTok';
                apiUrl = 'https://www.tikwm.com/api/?url=' + encodeURIComponent(url);
            } else {
                apiUrl = 'https://api.ikyyxd.my.id/download/all-in-one?url=' + encodeURIComponent(url);
            }
            
            const resp = await fetch(apiUrl);
            const data = await resp.json();
            let hasVideo = false;
            let hasImages = false;
            const mediaItems = [];
            
            // Instagram
            if (platform === 'Instagram' && data.status === true && data.result) {
                data.result.forEach(item => {
                    const mediaUrl = item.url;
                    const size = item.size || 'Unknown';
                    const isVideo = mediaUrl && (mediaUrl.includes('.mp4') || mediaUrl.includes('video'));
                    const isImage = mediaUrl && (mediaUrl.includes('.jpg') || mediaUrl.includes('.jpeg') || mediaUrl.includes('.png'));
                    
                    if (isVideo) {
                        hasVideo = true;
                        mediaItems.push({ type: 'video', url: mediaUrl, size: size });
                    } else {
                        hasImages = true;
                        mediaItems.push({ type: 'image', url: mediaUrl, size: size });
                    }
                });
                
                let html = '<div class="ig-item">';
                html += '<div class="ig-source"><i class="fab fa-instagram"></i> INSTAGRAM</div>';
                html += `<div class="ig-meta"><i class="fas fa-image"></i> ${data.total} media ditemukan</div>`;
                
                mediaItems.forEach((media, idx) => {
                    const fileName = `instagram_${idx+1}.${media.type === 'video' ? 'mp4' : 'jpg'}`;
                    
                    if (media.type === 'video') {
                        html += `<video class="ig-media" controls src="${media.url}" preload="metadata"></video>`;
                    } else {
                        html += `<img class="ig-media" src="${media.url}" alt="Media ${idx+1}" loading="lazy">`;
                    }
                    
                    html += `<div style="margin-top:6px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;">`;
                    html += `<span style="font-size:0.7rem;color:#6a6a6a;"><i class="fas fa-file"></i> ${media.size}</span>`;
                    html += `<button class="ig-dl-btn" data-url="${media.url}" data-name="${fileName}"><i class="fas fa-download"></i> Download ${media.type === 'video' ? 'Video' : 'Foto'} ${idx+1}</button>`;
                    html += `</div>`;
                });
                
                html += '</div>';
                allResult.innerHTML = html;
                
                allResult.querySelectorAll('.ig-dl-btn').forEach(btn => {
                    btn.addEventListener('click', function() {
                        window.secureDownload(this.dataset.url, this.dataset.name);
                    });
                });
                
                window.showNotification('success', '🔥 NdizzXD', 'Wah User Download Instagram NdizzXD Muncul Nieh Hormat Grak!', 5000);
                return;
            }
            
            // TikTok
            if (platform === 'TikTok' && data.code === 0 && data.data) {
                const d = data.data;
                hasVideo = !!d.play;
                hasImages = d.images && d.images.length > 0;
                
                let html = '<div class="ig-item">';
                html += '<div class="ig-source"><i class="fab fa-tiktok"></i> TIKTOK</div>';
                
                if (d.author) {
                    html += `<div class="ig-author"><i class="fas fa-user"></i> ${d.author}</div>`;
                }
                if (d.title) {
                    html += `<div class="ig-title">${d.title}</div>`;
                }
                
                if (d.play) {
                    html += `<video class="ig-media" controls src="${d.play}" preload="metadata"></video>`;
                    html += `<div><button class="ig-dl-btn" data-url="${d.play}" data-name="tiktok_video.mp4"><i class="fas fa-download"></i> Download Video</button></div>`;
                }
                if (d.music) {
                    html += `<div style="margin-top:8px;"><button class="ig-dl-btn" data-url="${d.music}" data-name="tiktok_audio.mp3"><i class="fas fa-download"></i> Download Audio</button></div>`;
                }
                if (d.images && d.images.length > 0) {
                    html += '<div class="photo-grid" style="display:flex;flex-wrap:wrap;gap:8px;margin-top:8px;">';
                    d.images.forEach((img, idx) => {
                        html += `<img src="${img}" style="width:80px;height:80px;object-fit:cover;border-radius:8px;cursor:pointer;" data-url="${img}" data-name="tiktok_img_${idx+1}.jpg">`;
                    });
                    html += '</div>';
                }
                
                html += '</div>';
                allResult.innerHTML = html;
                
                allResult.querySelectorAll('.ig-dl-btn').forEach(btn => {
                    btn.addEventListener('click', function() {
                        window.secureDownload(this.dataset.url, this.dataset.name);
                    });
                });
                allResult.querySelectorAll('.photo-grid img').forEach(img => {
                    img.addEventListener('click', function() {
                        window.secureDownload(this.dataset.url, this.dataset.name);
                    });
                });
                
                window.showNotification('success', '🔥 NdizzXD', 'Wah User Download TikTok NdizzXD Muncul Nieh Hormat Grak!', 5000);
                return;
            }
            
            // All-in-One Fallback
            if (data.status === true && data.result) {
                const d = data.result;
                let html = '<div class="ig-item">';
                html += '<div class="ig-source"><i class="fas fa-globe"></i> ALL-IN-ONE</div>';
                
                if (d.title) html += `<div class="ig-title">${d.title}</div>`;
                if (d.author) html += `<div class="ig-author"><i class="fas fa-user"></i> ${d.author}</div>`;
                
                if (d.thumbnail) {
                    html += `<img class="ig-thumb" src="${d.thumbnail}" alt="Thumbnail" loading="lazy">`;
                }
                
                if (d.url) {
                    const isVideo = d.url.includes('.mp4') || d.url.includes('video');
                    const fileName = `${platform || 'media'}_download.${isVideo ? 'mp4' : 'jpg'}`;
                    
                    if (isVideo) {
                        html += `<video class="ig-media" controls src="${d.url}" preload="metadata"></video>`;
                    } else {
                        html += `<img class="ig-media" src="${d.url}" alt="Media" loading="lazy">`;
                    }
                    html += `<div><button class="ig-dl-btn" data-url="${d.url}" data-name="${fileName}"><i class="fas fa-download"></i> Download</button></div>`;
                }
                
                html += '</div>';
                allResult.innerHTML = html;
                
                allResult.querySelectorAll('.ig-dl-btn').forEach(btn => {
                    btn.addEventListener('click', function() {
                        window.secureDownload(this.dataset.url, this.dataset.name);
                    });
                });
                
                window.showNotification('success', '🔥 NdizzXD', 'Wah User Download All-in-One NdizzXD Muncul Nieh Hormat Grak!', 5000);
                return;
            }
            
            // Error
            const errMsg = data.message || data.msg || data.error || 'Gagal mengambil data.';
            allResult.innerHTML = `<div class="ig-item"><div class="ig-error"><i class="fas fa-exclamation-circle"></i> ${errMsg}</div></div>`;
            window.showNotification('error', 'Gagal', errMsg, 3000);
            
        } catch (err) {
            console.error('All-in-One Error:', err);
            allResult.innerHTML = `<div class="ig-item"><div class="ig-error"><i class="fas fa-exclamation-circle"></i> Error: ${err.message}</div></div>`;
            window.showNotification('error', 'Gagal', 'Terjadi kesalahan: ' + err.message, 3000);
        } finally {
            btnLabel.style.opacity = '1';
            btnSpin.style.display = 'none';
        }
    });

    // ===== CLEAR HISTORY =====
    clearHistoryBtn.addEventListener('click', function() {
        window.saveHistory([]);
        window.renderHistory();
        window.showNotification('info', 'Riwayat dihapus', 'Semua riwayat download telah dibersihkan.', 2000);
    });

    // ===== INIT =====
    buildInputs(1);
    window.renderHistory();
    
    setTimeout(() => {
        loadingOverlay.style.display = 'none';
    }, 300);
});