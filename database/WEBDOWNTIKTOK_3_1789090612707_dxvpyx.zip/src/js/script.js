import { 
    sanitizeHTML, 
    sanitizeUrl,
    isValidDomain, 
    encryptData, 
    decryptData,
    RateLimiter,
    obscureCode,
    preventIframe
} from './security.js';

// ===== AKTIFKAN KEAMANAN =====
preventIframe();
obscureCode();

// ============================================================
//  GLOBAL RATE LIMITER
// ============================================================
const rateLimiter = new RateLimiter(8, 60000);

// ============================================================
//  NOTIFICATION (AMAN)
// ============================================================
const notif = document.getElementById('globalNotif');
const notifIcon = document.getElementById('notifIcon');
const notifTitle = document.getElementById('notifTitle');
const notifMsg = document.getElementById('notifMsg');
const notifClose = document.getElementById('notifClose');
let notifTimer = null;

window.showNotification = function(type, title, message, duration = 4000) {
    if (notifTimer) clearTimeout(notifTimer);
    
    const icons = {
        success: '<i class="fas fa-check-circle"></i>',
        error: '<i class="fas fa-times-circle"></i>',
        warning: '<i class="fas fa-exclamation-triangle"></i>',
        info: '<i class="fas fa-bolt"></i>'
    };
    
    notifIcon.innerHTML = icons[type] || icons.info;
    notifIcon.className = 'notification-icon ' + type;
    notifTitle.textContent = title || 'NdizzXD';
    notifMsg.textContent = message || 'Selamat datang di NdizzXD Downloader';
    
    notif.classList.add('show');
    
    if (duration > 0) {
        notifTimer = setTimeout(() => {
            notif.classList.remove('show');
        }, duration);
    }
};

if (notifClose) {
    notifClose.addEventListener('click', () => {
        notif.classList.remove('show');
        if (notifTimer) clearTimeout(notifTimer);
    });
}

// ============================================================
//  PORTFOLIO - START
// ============================================================
document.getElementById('startBtn')?.addEventListener('click', () => {
    window.location.href = '/dashboard.html';
});

document.getElementById('backBtn')?.addEventListener('click', () => {
    window.location.href = '/';
});

// ============================================================
//  HISTORY (Encrypted)
// ============================================================
window.getHistory = function() {
    try {
        const encrypted = localStorage.getItem('dh_enc');
        if (!encrypted) return [];
        return decryptData(encrypted) || [];
    } catch {
        return [];
    }
};

window.saveHistory = function(history) {
    try {
        const encrypted = encryptData(history);
        if (encrypted) {
            localStorage.setItem('dh_enc', encrypted);
        }
    } catch {
        // Silent fail
    }
};

window.addToHistory = function(entry) {
    const history = getHistory();
    const filtered = history.filter(h => h.url !== entry.url);
    filtered.unshift({
        url: sanitizeUrl(entry.url),
        type: entry.type || 'Link',
        hasVideo: entry.hasVideo || false,
        hasAudio: entry.hasAudio || false,
        hasImages: entry.hasImages || false,
        timestamp: Date.now()
    });
    if (filtered.length > 100) filtered.length = 100;
    saveHistory(filtered);
    renderHistory();
};

window.renderHistory = function() {
    const history = getHistory();
    const historyList = document.getElementById('historyList');
    
    if (!historyList) return;
    
    if (history.length === 0) {
        historyList.innerHTML = `<div class="history-empty">
            <i class="far fa-folder-open" style="display:block;font-size:1.6rem;margin-bottom:10px;color:#2a2a2a;"></i>
            Belum ada riwayat download
        </div>`;
        return;
    }
    
    let html = '';
    history.forEach(item => {
        const time = new Date(item.timestamp);
        const timeStr = time.toLocaleDateString('id-ID', {
            day: '2-digit',
            month: 'short',
            hour: '2-digit',
            minute: '2-digit'
        });
        
        let badges = '';
        if (item.hasVideo) badges += '<span>Video</span>';
        if (item.hasAudio) badges += '<span>Audio</span>';
        if (item.hasImages) badges += '<span>Foto</span>';
        if (!badges) badges = `<span>${item.type || 'Media'}</span>`;
        
        const displayUrl = item.url.length > 40 ? item.url.substring(0, 40) + '...' : item.url;
        
        html += `<div class="history-item">
            <span class="h-icon"><i class="fas fa-link"></i></span>
            <span class="h-link" title="${sanitizeHTML(item.url)}">${sanitizeHTML(displayUrl)}</span>
            <span class="h-badge">${badges}</span>
            <span class="h-time">${timeStr}</span>
            <span class="h-delete" data-url="${sanitizeHTML(item.url)}"><i class="fas fa-times"></i></span>
        </div>`;
    });
    
    historyList.innerHTML = html;
    
    historyList.querySelectorAll('.h-delete').forEach(el => {
        el.addEventListener('click', function(e) {
            e.stopPropagation();
            const url = this.dataset.url;
            const history = getHistory();
            const filtered = history.filter(h => h.url !== url);
            saveHistory(filtered);
            renderHistory();
        });
    });
};

// ============================================================
//  SECURE DOWNLOAD
// ============================================================
window.secureDownload = async function(fileUrl, fileName) {
    if (!rateLimiter.canMakeRequest()) {
        showNotification('error', 'Terlalu banyak request', 'Coba lagi dalam 1 menit.', 3000);
        return;
    }
    
    if (!isValidDomain(fileUrl)) {
        showNotification('error', 'URL tidak valid', 'Domain tidak diizinkan.', 3000);
        return;
    }
    
    const overlay = document.getElementById('loadingOverlay');
    const sub = document.getElementById('loadingSub');
    
    overlay.style.display = 'flex';
    sub.textContent = `Mengunduh ${sanitizeHTML(fileName)}`;
    
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 15000);
        
        const response = await fetch(fileUrl, {
            signal: controller.signal,
            mode: 'cors',
            headers: {
                'Accept': 'video/*,image/*,audio/*,*/*'
            }
        });
        
        clearTimeout(timeoutId);
        
        if (!response.ok) throw new Error('Download failed');
        
        const blob = await response.blob();
        const blobUrl = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = blobUrl;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(blobUrl);
        
        showNotification('success', 'Berhasil', `File ${fileName} terunduh.`, 2500);
    } catch (error) {
        console.error('Download error:', error);
        showNotification('error', 'Gagal', 'Gagal mengunduh file. Buka di tab baru.', 3000);
        window.open(fileUrl, '_blank');
    } finally {
        overlay.style.display = 'none';
    }
};

// ============================================================
//  INISIALISASI
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
    renderHistory();
    
    setTimeout(() => {
        showNotification('info', '🚀 NdizzXD', 'Gunakan tab TikTok, Instagram, atau All-in-One untuk mulai download.', 3000);
    }, 500);
});