// ============================================================
//  SECURITY.JS — Pure Client-Side Security
// ============================================================

// ===== XSS PROTECTION =====
export function sanitizeHTML(str) {
    if (!str) return '';
    const temp = document.createElement('div');
    temp.textContent = str;
    return temp.innerHTML;
}

// ===== SANITASI UNTUK URL =====
export function sanitizeUrl(url) {
    if (!url) return '';
    return url.replace(/[^a-zA-Z0-9\-_.~:?=&/%#+]/g, '');
}

// ===== VALIDASI DOMAIN =====
const ALLOWED_DOMAINS = [
    'tiktok.com', 
    'instagram.com', 
    'youtube.com', 
    'facebook.com', 
    'twitter.com',
    'x.com',
    'youtu.be'
];

export function isValidDomain(url) {
    try {
        const parsed = new URL(url);
        return ALLOWED_DOMAINS.some(domain => 
            parsed.hostname.includes(domain) || 
            parsed.hostname.endsWith(domain)
        );
    } catch {
        return false;
    }
}

// ===== ENKRIPSI UNTUK LOCALSTORAGE =====
export function encryptData(data) {
    try {
        const json = JSON.stringify(data);
        let obfuscated = '';
        for (let i = 0; i < json.length; i++) {
            obfuscated += String.fromCharCode(json.charCodeAt(i) + 3);
        }
        return btoa(encodeURIComponent(obfuscated));
    } catch {
        return null;
    }
}

export function decryptData(encrypted) {
    try {
        const obfuscated = decodeURIComponent(atob(encrypted));
        let json = '';
        for (let i = 0; i < obfuscated.length; i++) {
            json += String.fromCharCode(obfuscated.charCodeAt(i) - 3);
        }
        return JSON.parse(json);
    } catch {
        return null;
    }
}

// ===== RATE LIMITING (Client-Side) =====
export class RateLimiter {
    constructor(maxRequests = 8, windowMs = 60000) {
        this.maxRequests = maxRequests;
        this.windowMs = windowMs;
        this.requests = [];
    }

    canMakeRequest() {
        const now = Date.now();
        this.requests = this.requests.filter(time => now - time < this.windowMs);
        
        if (this.requests.length >= this.maxRequests) {
            return false;
        }
        
        this.requests.push(now);
        return true;
    }
}

// ===== OBSCURE SOURCE CODE =====
export function obscureCode() {
    // Nonaktifkan right-click
    document.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        const notif = document.getElementById('globalNotif');
        if (notif) {
            const icon = document.getElementById('notifIcon');
            const title = document.getElementById('notifTitle');
            const msg = document.getElementById('notifMsg');
            if (icon) icon.innerHTML = '<i class="fas fa-shield-alt"></i>';
            if (title) title.textContent = '🔒';
            if (msg) msg.textContent = 'Klik kanan dinonaktifkan untuk keamanan.';
            notif.classList.add('show');
            setTimeout(() => notif.classList.remove('show'), 1500);
        }
    });

    // Nonaktifkan Ctrl+U (View Source)
    document.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 'u') {
            e.preventDefault();
            return false;
        }
        if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'i' || e.key === 'I' || e.key === 'j' || e.key === 'J')) {
            e.preventDefault();
            return false;
        }
        if (e.key === 'F12') {
            e.preventDefault();
            return false;
        }
    });
}

// ===== CEK APAKAH DI IFRAME =====
export function preventIframe() {
    if (window.self !== window.top) {
        document.body.innerHTML = `
            <div style="display:flex;align-items:center;justify-content:center;height:100vh;background:#000;color:#fff;font-family:sans-serif;flex-direction:column;gap:20px;">
                <i class="fas fa-shield-alt" style="font-size:48px;color:#ff4444;"></i>
                <h2>🔒 Akses Diblokir</h2>
                <p>Website ini tidak boleh dijalankan di dalam iframe.</p>
            </div>
        `;
        throw new Error('Iframe detected');
    }
}

// ============================================================
//  EXPOSE KE GLOBAL
// ============================================================
window.sanitizeHTML = sanitizeHTML;
window.sanitizeUrl = sanitizeUrl;
window.isValidDomain = isValidDomain;
window.encryptData = encryptData;
window.decryptData = decryptData;
window.RateLimiter = RateLimiter;
window.obscureCode = obscureCode;
window.preventIframe = preventIframe;